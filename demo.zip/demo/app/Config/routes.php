<?php
/**
 * Routes configuration
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different urls to chosen controllers and their actions (functions).
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
/**
 * Here, we are connecting '/' (base path) to controller called 'Pages',
 * its action called 'display', and we pass a param to select the view file
 * to use (in this case, /app/View/Pages/home.ctp)...
 */

	Router::connect('/', array('controller' => 'users', 'action' => 'login'));
  //  Router::connect('/', array('controller' => 'users', 'action' => 'demo'));   
       
/**
 * cofig controller ,
 */ 
        Router::connect('/my-look-ups',array('controller' => 'look_ups', 'action' => 'index'));
        Router::connect('/action-items',array('controller' => 'action_items', 'action' => 'index'));
        Router::connect('/my-builders',array('controller' => 'builder', 'action' => 'index'));
        //Router::connect('/my-builders/*',array('controller' => 'builder', 'action' => 'index'));
        Router::connect('/my-projects',array('controller' => 'project', 'action' => 'index'));
        //Router::connect('/my-projects/*',array('controller' => 'project', 'action' => 'index'));
        Router::connect('/my-clients',array('controller' => 'lead', 'action' => 'index'));
        //Router::connect('/my-clients/*',array('controller' => 'lead', 'action' => 'index'));
        Router::connect('/my-cities',array('controller' => 'city', 'action' => 'index'));
        //Router::connect('/my-cities/*',array('controller' => 'city', 'action' => 'index'));
        
        Router::connect('/my-channels',array('controller' => 'channel', 'action' => 'index'));
        Router::connect('/my-suburbs',array('controller' => 'suburb', 'action' => 'index'));
        Router::connect('/my-areas',array('controller' => 'areas', 'action' => 'index'));
        Router::connect('/my-permissions',array('controller' => 'permission_sets', 'action' => 'index'));
        Router::connect('/my-groups',array('controller' => 'users', 'action' => 'group'));
        Router::connect('/my-roles',array('controller' => 'roles', 'action' => 'index'));
        Router::connect('/my-users',array('controller' => 'users', 'action' => 'index'));
        
        Router::connect('/my-users/:slug-:id',array('controller' => 'users', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-roles/:slug-:id',array('controller' => 'roles', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-groups/:slug-:id',array('controller' => 'users', 'action' => 'group_edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-areas/:slug-:id',array('controller' => 'areas', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-suburbs/:slug-:id',array('controller' => 'suburb', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-channels/:slug-:id',array('controller' => 'channel', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-cities/:slug-:id',array('controller' => 'city', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-clients/:slug-:id',array('controller' => 'lead', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-clients/view/:slug-:id',array('controller' => 'lead', 'action' => 'view'),array('pass' => array('id', 'slug')));
        Router::connect('/my-projects/:slug-:id',array('controller' => 'project', 'action' => 'edit'),array('pass' => array('id', 'slug')));
        Router::connect('/my-builders/:slug-:id',array('controller' => 'builder', 'action' => 'edit'),array('pass' => array('id', 'slug')));
		 Router::connect('/my-builders/view/:slug-:id',array('controller' => 'builder', 'action' => 'view'),array('pass' => array('id', 'slug')));

       /* 
Router::connect("/message/:storesection/", 
    array(
        'controller' => 'messages', 'action' => 'index'
    ), 
    array(
        
        'pass' => array('category', 'productname', 'storesection')
    )
);
*/
       // Router::redirect('/message/:id',array('controller' => 'messages', 'action' => 'index'),array('persistent' => true, 'pass' => array('slug','id')));
/**
 * Load all plugin routes. See the CakePlugin documentation on
 * how to customize the loading of plugin routes.
 */
	CakePlugin::routes();

/**
 * Load the CakePHP default routes. Only remove this if you do not want to use
 * the built-in default routes.
 */
	require CAKE . 'Config' . DS . 'routes.php';
