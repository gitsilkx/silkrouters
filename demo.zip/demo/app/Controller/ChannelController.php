<?php
class ChannelController extends AppController {
	var $uses = array('Channel','ChannelRole','User','City','LookupValueStatus','LookupValueChannelRole');
	
	public $helpers = array('Html', 'Form', 'Session');
	public $components = array('Session');
	
	public function index() {
		
		$dummy_status = $this->Auth->user('dummy_status');
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		$search_condition = array();
		if($dummy_status)	
			 array_push($search_condition, array('Channel.dummy_status' => $dummy_status));
		
		$this->paginate['order'] = array('Channel.channel_name' => 'asc');
		$this->set('channels', $this->paginate("Channel", $search_condition));
		
		$channel_name = $this->Channel->find('list', array('fields' => 'Channel.id, Channel.channel_name','conditions' => $condition_dummy_status, 'order' => 'Channel.channel_name ASC'));
		$this->set('channel_name', $channel_name);
	//pr($channel_name);

		$channel_city = $this->City->find('list', array('fields'=>array('City.id','City.city_name'),'conditions' => $condition_dummy_status, 'order' => 'City.city_name ASC'));
		$this->set('channel_city', $channel_city);
		
	}
	
	public function add() {
		
	$dummy_status = $this->Auth->user('dummy_status');
	$condition_dummy_status = array('dummy_status' => $dummy_status);
	
	
        if ($this->request->is('post')) {
	
	    $this->request->data['Channel']['dummy_status'] = $dummy_status;		
		
            $this->Channel->create();
            if ($this->Channel->save($this->request->data)) {
                $this->Session->setFlash('Channel Name has been saved.','success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash('Unable to add Channel Name.','failure');
            }
        }	
		
		$cities = $this->Channel->City->find('all', array('conditions' => $condition_dummy_status,'order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		
		$this->set('cities', $arrCity);
		
		
		
		$channelroles = $this->LookupValueChannelRole->find('list',array('fields' => array('id','value'),'order' => 'value asc'));
		$this->set(compact('channelroles'));
		
	
		/*$this->loadModel('User');
			$this->set('users',$this->User->find('list',array('fields'=>array('User.fname' => 'User.fname'))));
			$this->set(compact('users'));
		*/	
	
		$user = $this->User->find('all', array('fields'=>array('User.id','User.fname','User.lname'),'conditions' => array('User.dummy_status' =>$dummy_status), 'order' => 'User.fname ASC'));
		$arrUser = array();
		if (count($user) > 0)
		{
			foreach ($user as $usr)
			{
				$arrUser[$usr['User']['id']] = $usr['User']['fname'].' '.$usr['User']['lname'];
			}
		}
		$this->set('user', $arrUser);

	}
	
 function edit($id = null)
	 {
		$id = base64_decode($id);
		if (!$id) {
			throw new NotFoundException(__('Invalid Channel Name'));
		}
	
		$channel = $this->Channel->findById($id);
		
		if (!$channel) {
			throw new NotFoundException(__('Invalid Channel Name'));
		}
	
		if ($this->request->data) {
			
			
			$this->Channel->id = $id;
			if ($this->Channel->save($this->request->data)) {
				$this->Session->setFlash('Channel Name has been updated.','success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Unable to update Channel Name.','failure');
			}
		}
		
		$status = $this->LookupValueStatus->find('list',array('fields' => array('id','value')));
		$this->set(compact('status'));
		
		$channelroles = $this->LookupValueChannelRole->find('list',array('fields' => array('id','value'),'order' => 'value asc'));
		$this->set(compact('channelroles'));
		
		$cities = $this->Channel->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		$this->set('cities', $arrCity);
		
		
		$user = $this->User->find('all', array('fields'=>array('User.id','User.fname','User.lname'), 'order' => 'User.fname ASC'));
		$arrUser = array();
		if (count($user) > 0)
		{
			foreach ($user as $usr)
			{
				$arrUser[$usr['User']['id']] = $usr['User']['fname'].' '.$usr['User']['lname'];
			}
		}
		$this->set('user', $arrUser);

	
		$this->request->data = $channel;
		
	}
function view($id = null){
	 
	 if (!$id) {
			throw new NotFoundException(__('Invalid Channel'));
		}
	
		$channel = $this->Channel->findById($id);
		
		if (!$channel) {
			throw new NotFoundException(__('Invalid Channel'));
		}
	
		$this->set('channel', $channel);

	 /*{
		if (!$id) {
			throw new NotFoundException(__('Invalid Channel Name'));
		}
	
		$channel = $this->Channel->findById($id);
		
		if (!$channel) {
			throw new NotFoundException(__('Invalid Channel Name'));
		}
	
		if ($this->request->data) {
			
			
			$this->Channel->id = $id;
			if ($this->Channel->save($this->request->data)) {
				$this->Session->setFlash('Channel Name has been updated.');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Unable to update Channel Name.');
			}
		}*/
	
		
		$cities = $this->Channel->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		$this->set('cities', $arrCity);
	
		$this->request->data = $channel;
		
	}


	 }
	 