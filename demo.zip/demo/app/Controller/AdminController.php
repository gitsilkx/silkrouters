<?php
class AdminController extends AppController
 {
	var $uses = null;
	
	
	function index() 
	{
	
	
	}
}