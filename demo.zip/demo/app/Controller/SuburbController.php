<?php
class SuburbController extends AppController {
	var $uses = array('Suburb','LookupValueStatus');

	public function index() {
		
		$dummy_status = $this->Auth->user('dummy_status');
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		$search_condition = array();
		if($dummy_status)	
			 array_push($search_condition, array('Suburb.dummy_status' => $dummy_status));
		
		$this->paginate['order'] = array('Suburb.suburb_name' => 'asc');
		$this->set('suburbs', $this->paginate("Suburb", $search_condition));
				
		
		$cities = $this->Suburb->City->find('all', array('conditions' => $condition_dummy_status,'order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		
		$this->set('cities', $arrCity);
		
		$suburb = $this->Suburb->find('list', array('fields' => 'Suburb.id, Suburb.suburb_name','conditions' => $condition_dummy_status, 'order' => 'Suburb.suburb_name ASC'));
			$this->set('suburb', $suburb);
		
	
		
	}
	
	public function add() {
	
		$dummy_status = $this->Auth->user('dummy_status');
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		$this->request->data['Suburb']['dummy_status'] = $dummy_status;
	
        if ($this->request->is('post')) {
            $this->Suburb->create();
            if ($this->Suburb->save($this->request->data)) {
                $this->Session->setFlash('Suburb has been saved.','success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash('Unable to add Suburb.','failure');
            }
        }	
		$cities = $this->Suburb->City->find('all', array('conditions' => array('City.dummy_status' => $dummy_status),'order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		
		$this->set('cities', $arrCity);
	}

	
	/*$cities = $this->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		
		$this->set('citiess', $arrCity);
	}
	*/
	
 function edit($id = null)
	 {
		$id = base64_decode($id);
		if (!$id) {
			throw new NotFoundException(__('Invalid Suburb'));
		}
	
		$suburb = $this->Suburb->findById($id);
		
		if (!$suburb) {
			throw new NotFoundException(__('Invalid suburb'));
		}
	
		if ($this->request->data) {
			
			
			$this->Suburb->id = $id;
			if ($this->Suburb->save($this->request->data)) {
				$this->Session->setFlash('Suburb has been updated.','success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Unable to update Suburb.','failure');
			}
		}
		
		$status = $this->LookupValueStatus->find('list',array('fields' => array('id','value')));
		$this->set(compact('status'));
	
		
		$cities = $this->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		$this->set('cities', $arrCity);
	
		$this->request->data = $suburb;
		
	}
 
	 public function view($id = null) {
		if (!$id) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$suburb = $this->Suburb->findById($id);
		
		if (!$suburb) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$this->set('suburb', $suburb);
			//$this->request->data = $city;
	

		
		$cities = $this->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		$this->set('cities', $arrCity);
	
		$this->request->data = $suburb;
		
	}

	public function getByCity() {
		$city_id = $this->request->data['Area']['city_id'];
 
		$suburbs = $this->Suburb->find('list', array('fields' => 'suburb_name', 
			'conditions' => array('Suburb.city_id' => $city_id),
			'recursive' => -1
			));
		$this->set('suburbs', $suburbs);		
		$this->layout = 'ajax';
	}
	
	
	
	function get_list_by_city(){
	
		$this->layout = 'ajax';
		$city_id = $this->request->data['Project']['city_id'];
		$suburbs = $this->Suburb->find('list', array('conditions' => array('Suburb.city_id' => $city_id), 'fields' => 'Suburb.id, Suburb.suburb_name', 'order' => 'Suburb.suburb_name ASC'));
		//pr($projects);
		$this->set('suburbs', $suburbs);
	}
	
	function get_list_by_city_for_builder(){
	
		$this->layout = 'ajax';
		$city_id = $this->request->data['Builder']['city_id'];
		$suburbs = $this->Suburb->find('list', array('conditions' => array('Suburb.city_id' => $city_id), 'fields' => 'Suburb.id, Suburb.suburb_name', 'order' => 'Suburb.suburb_name ASC'));
		//pr($projects);
		$this->set('suburbs', $suburbs);
	}
	
	function get_list_by_city_for_filter(){
	
		$this->layout = 'ajax';
		$city_id = $this->request->data['Suburb']['city_id'];
		$suburbs = $this->Suburb->find('list', array('conditions' => array('Suburb.city_id' => $city_id), 'fields' => 'Suburb.id, Suburb.suburb_name', 'order' => 'Suburb.suburb_name ASC'));
		//pr($projects);
		$this->set('suburb', $suburbs);
	}

	


}
	 