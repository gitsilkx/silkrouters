<?php
App::uses('CakeEmail', 'Network/Email');
class ActionItemsController extends AppController{
    var $uses = array('Amenity', 'Group','City','Channel','Project','Lead','Builder','Role','ActionItem','ActionItemType','Remark','Channel','ActionItemLevel','LookupValueProjectUnitType','LookupValueActionItemRejection','LookupValueActionItemReturn','LeadStatus','Suburb','Area','User');
    public $components = array('Sms');
    
	public function index(){
	    
	 $dummy_status = $this->Auth->user('dummy_status');
         //$condition_dummy_status = array('dummy_status' => $dummy_status);
         $role_id = $this->Session->read("role_id");
        $channel_id = $this->Session->read("channel_id");
         $channels = $this->Channel->findById($channel_id);
		
		 
        $channel_head = $channels['Channel']['channel_head'];
	  
        $user_id = $this->Auth->user('id');
       //  $city_id = $this->Auth->user('city_id');
		  $city_id = $channels['Channel']['city_id'];
         $roles = $this->Role->find('all',array('conditions' => 'Role.id = '.$role_id));
		// pr($roles);
		
         $this->set(compact('roles'));
        $group_user = $roles[0]['Role']['id'];
	 
	$search_condition = array();
	
	if ($this->request->is('post') || $this->request->is('put')) {
	    
	    if (!empty($this->data['ActionItem']['global_search'])) {
		$search = $this->data['ActionItem']['global_search'];         
		array_push($search_condition, array('OR' => array('Lead.lead_fname' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%", 'Project.project_name' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%", 'Builder.builder_name' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%")));
	    }
	    if (!empty($this->data['ActionItem']['lead_id'])) {
			 $search = $this->data['ActionItem']['lead_id'];
			array_push($search_condition, array('Lead.lead_id' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     
	   
	    
	    if (!empty($this->data['ActionItem']['action_item_level_id'])) {
		$search = $this->data['ActionItem']['action_item_level_id'];
	       array_push($search_condition, array('ActionItem.action_item_level_id' => mysql_escape_string(trim(strip_tags($search)))));
	    }
	    if (!empty($this->data['ActionItem']['type_id'])) {
		$search = $this->data['ActionItem']['type_id'];
	       array_push($search_condition, array('ActionItem.type_id' => mysql_escape_string(trim(strip_tags($search)))));
	    }
	    if (!empty($this->data['ActionItem']['lead_status'])) {
		$search = $this->data['ActionItem']['lead_status'];
	       array_push($search_condition, array('Lead.lead_status' => mysql_escape_string(trim(strip_tags($search)))));
	    }

	    
	}
	
	if($dummy_status)
	    array_push($search_condition, array('ActionItem.dummy_status' => $dummy_status));
	 
	 
	 
      
        if($channel_id == '2' || $channel_id == '4' ||  $channel_id == '136'|| $group_user == '4'){ // 136 for dummy user and cheking for Global Administration Channel or Global Business Admin Channel from chennels table  
		//if($group_user == '13') {  // 13 for business admin for channel_role of lookup_value_channel_roles table
           if($city_id == '1' || $city_id == '12'){ //city for global 
	   
                $this->paginate['conditions'][0] = "ActionItem.action_item_level_id = 1 AND ActionItem.action_item_active='Yes' AND (ActionItem.type_id = 1 OR ActionItem.type_id = 8) AND Lead.lead_managerprimary IS NULL AND Lead.lead_managersecondary IS NULL AND ActionItem.next_action_by = ".$user_id."";
		$this->paginate['conditions'][1] = $search_condition;
		
	   }
           else{
	    
                $this->paginate['conditions'][0] = "ActionItem.action_item_level_id = 1 AND ActionItem.action_item_active='Yes' AND Lead.city_id ='$city_id' AND (ActionItem.type_id = 1 OR ActionItem.type_id = 8) AND Lead.lead_managerprimary IS NULL AND Lead.lead_managersecondary IS NULL AND ActionItem.next_action_by = ".$user_id."";
		$this->paginate['conditions'][1] = $search_condition;
                }
			 $this->paginate['order'] = array('ActionItem.created' => 'desc');	
   
           $this->set('actionitems',$this->paginate("ActionItem"));
        }
        elseif($group_user == '7'){ // FOR Execution Manager
		
            $this->paginate['conditions'][0] = "ActionItem.action_item_level_id = 1 AND ActionItem.type_id = 4 AND Lead.lead_managerprimary = $user_id AND ActionItem.action_item_active='Yes' AND ActionItem.next_action_by = ".$user_id."";
	    $this->paginate['conditions'][1] = $search_condition;
		$this->paginate['order'] = array('ActionItem.created' => 'desc');	
            $this->set('actionitems',$this->paginate("ActionItem"));
        }
        elseif($group_user == '8'){ // FOR TEAM MEMBER
           $this->paginate['conditions'][0] = "ActionItem.action_item_level_id = 1 AND ActionItem.type_id = 5 AND Lead.lead_managersecondary = $user_id  AND ActionItem.action_item_active='Yes' AND ActionItem.next_action_by = ".$user_id."";
	   $this->paginate['conditions'][1] = $search_condition;
	   $this->paginate['order'] = array('ActionItem.created' => 'desc');	
            $this->set('actionitems',$this->paginate("ActionItem"));
        }
       // $log = $this->ActionItem->getDataSource()->getLog(false, false);       
       // debug($log);
      //  pr($actionitems);
	  
	$action_level = $this->ActionItemLevel->find('list',array('fields' => array('id','level'),'order' => 'level asc'));
	$this->set(compact('action_level'));
	
	$status = $this->LeadStatus->find('list',array('fields' => array('id','status')));
	$this->set(compact('status'));
	
	$action_type = $this->ActionItemType->find('list',array('fields' => array('id','type'),'order' => 'type asc'));
	$this->set(compact('action_type'));
	
	$action_about = $this->Lead->find('all',array('fields' => array('id','lead_fname','lead_lname'),'order'=> 'lead_fname asc'));

    $action_about = Set::combine($action_about, '{n}.Lead.id',array('%s %s','{n}.Lead.lead_fname','{n}.Lead.lead_lname'));
	$this->set(compact('action_about'));
	
			
	


    }
    
    public function add($actio_itme_id = null) {
         $this->layout = '';
		 
		 /***********Checking user************/
	 $dummy_status = $this->Auth->user('dummy_status');		 
	 $channel_id = $this->Session->read("channel_id");
         $channels = $this->Channel->findById($channel_id);
		
         $channel_head = $channels['Channel']['channel_head'];
		 $channel_city_id = $channels['Channel']['city_id'];
         $user_id = $this->Auth->user('id');
		  $role_id = $this->Session->read("role_id");
		 $roles = $this->Role->find('all',array('conditions' => 'Role.id = '.$role_id));
         $group_user = $roles[0]['Role']['id'];
		 $general_exu_id = '';
		 
        
		 
		  if($channel_id == '2' || $channel_id == '4' || $channel_id == '136' || $group_user == '4'){ //cheking for Global Administration Channel or Global Business Admin Channel from chennels table   
		  		$this->set('user_type','Global');
				$type = $this->ActionItemType->find('list',array('fields' => array('id','type'),'conditions' =>'ActionItemType.id = 4 OR ActionItemType.id = 9'));
		  }
		  elseif($group_user == '7' ){ // FOR PRIMARY MANAGER
		   		$this->set('user_type','Execution');
				$type = $this->ActionItemType->find('list',array('fields' => array('id','type'),'conditions' =>'ActionItemType.id = 3 OR ActionItemType.id = 5 OR ActionItemType.id = 8'));
		   }
		  elseif($group_user == '8' ){ // FOR TEAM MEMBER
				$this->set('user_type','Team');
				$type = $this->ActionItemType->find('list',array('fields' => array('id','type'),'conditions' =>'ActionItemType.id = 3 OR ActionItemType.id = 8')); // 2 = Acceptance , 8 = Return of action_item_types
			}
			
			
        $this->set(compact('type'));
		 
		 
		 
		 
         //$city_id = $this->Auth->user("city_id");
         $id = $this->Auth->user("id");
         $actionitems = $this->ActionItem->findById($actio_itme_id);
       // pr($actionitems);
		//die;
        $city_id = $actionitems['Lead']['city_id'];
       // die;
         $this->set(compact('actionitems')); 

        if ($this->request->is('post')) {
 				
				$this->request->data['ActionItem']['action_item_created'] = date('Y-m-d');
				$this->request->data['ActionItem']['created_by_id'] = $id;
				$this->request->data['ActionItem']['action_item_active'] = 'Yes';
				$this->request->data['ActionItem']['dummy_status'] = $dummy_status;
				$this->request->data['ActionItem']['action_item_status'] = '4'; // 4 for allocated of lookup_value_action_item_statuses
				$this->request->data['ActionItem']['parent_action_item_id'] = $actio_itme_id;
				$this->request->data['ActionItem']['created_by'] = $id;
				$lead_status = '2';  // 2 for allocated of lookup_value_leads_statuses
				$this->request->data['Remark']['remarks'] = 'Allocated';
				$this->request->data['ActionItem']['description'] = 'Allocated';
				$this->request->data['Remark']['created_by'] = $id;
				$this->request->data['Remark']['remarks_by'] = $id;
				$this->request->data['Remark']['lead_id'] = $this->data['ActionItem']['lead_id'];
				$this->request->data['Remark']['remarks_date'] = date('Y-m-d');
				$this->request->data['Remark']['remarks_level'] = '3'; //3 for client from lookup_value_remarks_level
				$this->request->data['Remark']['remarks_time'] = date('g:i A');
				$channel_id = $this->request->data['ActionItem']['allocated_channel_id'];
				
           
	    if($this->data['ActionItem']['type_id'] == 9){  // 9 for rejection.
                
				$this->request->data['ActionItem']['primary_manager_id'] = NULL;
                $this->request->data['ActionItem']['allocated_channel_id'] = NULL;
				$this->request->data['Remark']['remarks'] = 'Rejection';
				$this->request->data['ActionItem']['action_item_status'] = '8'; // 8 for Return of lookup_value_action_item_statuses
				$lead_status = '5'; // 5 for return of lookup_value_leads_statuses
    			$this->request->data['ActionItem']['description'] = 'Rejection';
				$this->data['Lead']['lead_channel'] = $channel_id;
				$this->data['Lead']['lead_managerprimary'] = $this->data['ActionItem']['primary_manager_id'];
				$this->data['Lead']['lead_status'] = '5'; // 5 for return of lookup_value_leads_statuses
				
				
            }
		
			
	    if($this->data['ActionItem']['type_id'] == 2){  // 4 for acceptance.
		
				$this->request->data['ActionItem']['description'] = 'Acceptance';
				$this->request->data['Remark']['remarks'] = 'Acceptance';
				$this->request->data['Lead']['lead_status'] = '4'; // 4 for Activation of lookup_value_leads_statuses
	      } 
		  if($this->data['ActionItem']['type_id'] == 4){  // 4 for Allocation.
				
				$this->request->data['Lead']['lead_managerprimary'] = $this->request->data['ActionItem']['primary_manager_id'];
				$this->request->data['ActionItem']['next_action_by'] = $this->request->data['ActionItem']['primary_manager_id'];
				$this->request->data['Lead']['lead_status'] = '2'; // for allocated of lead_statues
		 
	      }
		   if($this->data['ActionItem']['type_id'] == 5){  // 5 for Re-Allocated of action_status.
		   		
				$this->request->data['ActionItem']['description'] = 'Re-Allocated';
				$this->request->data['ActionItem']['primary_manager_id'] = NULL;
				$this->request->data['ActionItem']['next_action_by'] = $this->data['ActionItem']['secondary_manager_id'];
				$this->request->data['Remark']['remarks'] = 'Acceptance';
				$this->request->data['Lead']['lead_status'] = '4'; // 4 for activated of lookup_value_leads_statuses
				$this->request->data['Lead']['lead_managersecondary'] = $this->data['ActionItem']['secondary_manager_id'];	 
				$this->request->data['Lead']['lead_status'] = '3'; //Re-Allocated of lead_status.
		   			
		   }
		   if($this->data['ActionItem']['type_id'] == 3){  // 3 for Activates.
		   
					$this->request->data['ActionItem']['description'] = 'Activates';
					$this->request->data['ActionItem']['primary_manager_id'] = NULL;
					$this->request->data['Lead']['lead_managersecondary'] = $user_id;
					$this->request->data['ActionItem']['next_action_by'] = $user_id;
					$this->request->data['Lead']['lead_managerprimary'] = NULL;
					$this->request->data['ActionItem']['secondary_manager_id'] =  $user_id;
					$this->request->data['Lead']['lead_status'] = '4'; //Activate of lead_status.

	      } 
	     if($this->data['ActionItem']['type_id'] == 8){  // 4 for return.
		    $this->request->data['ActionItem']['description'] = 'Return';
		     $this->request->data['Remark']['remarks'] = 'Return';
		      $this->request->data['Lead']['lead_status'] = '5'; // 5 for Returned of lead status
			  			
						
			$business_admin = $this->Channel->find('first',array('conditions' => array('Channel.city_id' => $this->data['ActionItem']['city_id'],'Channel.channel_role' => '13','Channel.dummy_status' => $dummy_status)));  // business admin logic. 13 for business admin of lookup_value_channel_roles table
			
			
		
				if(!empty($business_admin))	{
				$next_action_id = $this->User->find('first',array('conditions' => array('User.business_admin_channel_id' => $business_admin['Channel']['id'],'User.business_admin_role_id' => 4,'User.dummy_status'=> $dummy_status))); // 4 for business admin of roles table	
					
					if(!empty($next_action_id)){
							
							 $this->request->data['ActionItem']['next_action_by'] = $next_action_id['User']['id'];
							 $this->request->data['ActionItem']['primary_manager_id'] = NULL;
							  $this->request->data['Lead']['lead_managersecondary'] = NULL;
							  $this->request->data['Lead']['lead_managerprimary'] = NULL;
							  $this->request->data['ActionItem']['secondary_manager_id'] = NULL;
					
					}
				
				}
			  
			  
	      } 
     		
            $channels = $this->Channel->find('all',array('conditions' => array('Channel.id' => $channel_id)));
           // $to = $channels[0]['User']['company_email_id'];
            $to = 'biswajit.das@webskitters.com';
		
            $this->ActionItem->create();
            if ($this->ActionItem->save($this->data['ActionItem'])) {
              // $this->ActionItem->id = $actio_itme_id;
               // $this->ActionItem->saveField('action_item_active' , 'No');
				$this->ActionItem->updateAll(array('ActionItem.action_item_active' => "'No'"),array('ActionItem.id' => $actio_itme_id));
                 //$this->Lead->id = $this->data['ActionItem']['lead_id'];
                $this->Lead->updateAll($this->data['Lead'],array('Lead.id' => $this->data['ActionItem']['lead_id']));
                
                
                 $this->Remark->save($this->data['Remark']);
                
                
                 //$this->Session->write('success_msg', 'Action Item has been saved.');
                /* Email Logic */ 
                $Email = new CakeEmail();
                $Email->viewVars(array(
                    'City' => $actionitems['City']['city_name'],
                    'Urgency' => $actionitems['Urgency']['value'],
                    'Importance' => $actionitems['Importance']['value'],
                    'Country' => $actionitems['Country']['value'],
                    'lead_primaryphonenumber' => $actionitems['Lead']['lead_primaryphonenumber'],
                    'lead_emailid' => $actionitems['Lead']['lead_emailid'],
                    'Area' => $actionitems['Area']['area_name'],
                    'Suburb' => $actionitems['Suburb']['suburb_name'],
                    'Builder' => $actionitems['Builder']['builder_name'],
                    'Project' => $actionitems['Project']['project_name'],
                    'TypeProject' => $actionitems['TypeProject']['value'],
                ));
                $Email->template('lead_template', 'default')->emailFormat('html')->to($to)->from('admin@silkrouters.com')->subject('Silkrouters - Allocation Lead')->send();
                 /* End Emial */
                 /* Phone API */
                 $msg = $actionitems['City']['city_name'].' | '.$actionitems['Urgency']['value'].' | '.$actionitems['Importance']['value'].' | '.$actionitems['Country']['value'].' | '.$actionitems['Lead']['lead_primaryphonenumber'].' | '.$actionitems['Lead']['lead_emailid'].' | '.$actionitems['Area']['area_name'].' , '.$actionitems['Suburb']['suburb_name'].' , '.$actionitems['Builder']['builder_name'].' , '.$actionitems['Project']['project_name'].' , '.$actionitems['TypeProject']['value'];
                 $authKey = Configure::read('sms_api_key');
		 $senderId = Configure::read('sms_sender_id');
               // $mobileNumber = $channels[0]['User']['primary_mobile_number'];
		$mobileNumber = "9433657552";
		$message = urlencode($msg);
		$route = "default";		
		//$this->Sms->send_sms($authKey,$mobileNumber,$message,$senderId,$route);
                
                /* End Phone */
                  $this->Session->setFlash('Action item  has been saved.', 'success_msg');
                echo '<script>parent.$.fancybox.close(); parent.location.reload(true);exit();</script>';
            } else {
                $this->Session->setFlash('Unable to add Action item.', 'failure');
            }
        }
              
        
        
		
		$conditions = array('city_id = "'.$city_id.'" AND (channel_role = 1 OR channel_role = 3)'); // 1 for Execution 3 for Consulting of lookup_value_channel_roles
        
        $channels = $this->Channel->find('list',array('fields' => array('id','channel_name'),
                                                      'conditions' => $conditions												  
											
													 ));
        $this->set(compact('channels'));
		
		$rejections = $this->LookupValueActionItemRejection->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('rejections'));
		
		$general_exu = $this->Channel->find('first', array('conditions' => array('Channel.city_id' => $channel_city_id , 'Channel.channel_role' => '16', 'Channel.dummy_status' => $dummy_status)));
		
		if(!empty($general_exu))
				$general_exu_id = $general_exu['Channel']['id'];
			
	
		
		$secondary_manager = $this->User->find('all',array('fields' => array('User.id','User.fname','User.mname','User.lname'),
                                                         'conditions' =>  array(
														 		 'OR' =>
																		array(
																			   'AND' => array(
																							 'User.exu_channel_id' => $channel_id,
																							  'User.exu_role_id' => '8', // Execution Associate of roles
																							  'User.dummy_status' => $dummy_status
																							

																						),
																				'OR' =>  array(
																						'AND' => array(
																							 'User.general_exe_channel_id' => $general_exu_id,
																							  'User.general_exe_role_id' => '9', // General Execution Associate of roles
																							   'User.dummy_status' => $dummy_status
																						  )
																					),
																						
																			 
																			 ),
																			 
																	)
														 
														 	
														 
												
														 
														 ));
						 
		// $log = $this->User->getDataSource()->getLog(false, false);       
        // debug($log);
		$secondary_manager = Set::combine($secondary_manager, '{n}.User.id',array('%s %s %s','{n}.User.fname','{n}.User.mname','{n}.User.lname'));
		$this->set(compact('secondary_manager'));
		
		
		$returns = $this->LookupValueActionItemReturn->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('returns'));
 
    }
    
    function edit($id = null) {
        
        $city_id = $this->Auth->user("city_id");
        if (!$id) {
            throw new NotFoundException(__('Invalid Builder'));
        }

        $action_item = $this->ActionItem->findById($id);

        if (!$action_item) {
            throw new NotFoundException(__('Invalid builder'));
        }

        if ($this->request->data) {


            $this->ActionItem->id = $id;
            $action_item_created= explode('/',$this->data['ActionItem']['action_item_created']);
            $date = $action_item_created[0];
            $month = $action_item_created[1];
            $year = $action_item_created[2];
            $this->request->data['ActionItem']['action_item_created'] = $year.'-'.$month.'-'.$date;
            
            if ($this->ActionItem->save($this->request->data)) {
                $this->Session->setFlash('Action Item has been updated.', 'success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash('Unable to update Action Item.', 'failure');
            }
        }
        
        $type = $this->ActionItemType->find('list',array('fields' => array('id','type')));
        $this->set(compact('type'));
        
        $channels = $this->Channel->find('list',array('fields' => array('id','channel_name'),
                                                      'conditions' => array('city_id ='.$city_id)));
        $this->set(compact('channels'));
        
        $leads = $this->Lead->find('all',array('fields' => array('Lead.id','Lead.lead_fname','Lead.lead_lname')));
        $leads = Set::combine($leads, '{n}.Lead.id',array('%s %s','{n}.Lead.lead_fname','{n}.Lead.lead_lname'));

        $this->set(compact('leads'));
        
        $levels = $this->ActionItemLevel->find('list',array('fields' => array('id','level')));
        $this->set(compact('levels'));

        $this->request->data = $action_item;
    }

}
?>