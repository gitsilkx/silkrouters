<?php

class AreasController extends AppController {
	var $uses =array( 'Builder','Area', 'Suburb','City','LookupValueStatus');

	public function index() {
	
		$dummy_status = $this->Auth->user('dummy_status');
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		
		$search_condition = array();
		if($dummy_status)	
			 array_push($search_condition, array('Area.dummy_status' => $dummy_status));
		
		$this->paginate['order'] = array('Area.area_name' => 'asc');
		$this->set('areas', $this->paginate("Area", $search_condition));
		
		
		$city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' => $condition_dummy_status, 'order' => 'City.city_name ASC'));
		$this->set('city', $city);
			
		$suburb = $this->Suburb->find('list', array('fields' => 'Suburb.id, Suburb.suburb_name','conditions' => $condition_dummy_status, 'order' => 'Suburb.suburb_name ASC'));
		$this->set('suburb', $suburb);
		
		$area = $this->Area->find('list', array('fields' => 'Area.id, Area.area_name','conditions' => $condition_dummy_status, 'order' => 'Area.area_name ASC'));
		$this->set('area', $area);
		
	
		
		
	}
	
	public function add() {
	
        if ($this->request->is('post')) {
            $this->Area->create();
            if ($this->Area->save($this->request->data)) {
                $this->Session->setFlash('Area has been saved.','success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash('Unable to add area.','failure');
            }
        }

		$result = $this->Area->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCities = array();
		$first_city_id = 0;
		if (count($result) > 0)
		{
			$ctr = 1;
			foreach ($result as $city)
			{
				$arrCities[$city["City"]["id"]] = $city["City"]["city_name"];
				if ($ctr == 1)
				{
					$first_city_id = $city["City"]["id"];
				}
				$ctr++;
			}
		}
		$this->set('cities', $arrCities);

		if ($first_city_id == 0)
		{
			$suburbs = $this->Area->Suburb->find('all', array('order' => 'Suburb.suburb_name ASC'));
		}
		else
		{
			$suburbs = $this->Area->Suburb->find('all', array('conditions'=>array('Suburb.city_id' => $first_city_id), 'order' => 'Suburb.suburb_name ASC'));
		}

		$arrSuburb = array();
		if (count($suburbs) > 0)
		{
			foreach ($suburbs as $suburb)
			{
				$arrSuburb[$suburb['Suburb']['id']] = $suburb['Suburb']['suburb_name'];
			}
		}
		
		$this->set('suburbs', $arrSuburb);
	}
	
	public function delete($id = null) 
	{
	$this->Area->create();
    if (!$this->request->is('post')) {
        throw new MethodNotAllowedException();
    }
    $this->Area->id = $id;
    if (!$this->Area->exists()) {
        throw new NotFoundException(__('Invalid area'));
    }
    if ($this->Area->delete()) {
        $this->Session->setFlash(__('Area deleted'));
        $this->redirect(array('action' => 'index'));
    }
    $this->Session->setFlash(__('Area was not deleted'));
    $this->redirect(array('action' => 'index'));
}
	
	
	
public function edit($id = null) {
		$id = base64_decode($id);
	
		if (!$id) {
			throw new NotFoundException(__('Invalid Area'));
		}
		
		$area = $this->Area->findById($id);

		if (!$area) {
			throw new NotFoundException(__('Invalid Area'));
		}

		if ($this->request->data) {
			
			$this->Area->id = $id;
			
			if ($this->Area->save($this->request->data)) {
				$this->Session->setFlash('Area has been updated.','success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Unable to update area.','failure');
			}
		}
		
		$status = $this->LookupValueStatus->find('list',array('fields' => array('id','value')));
		$this->set(compact('status'));
		
		   $suburbs = $this->Area->Suburb->find('all', array('order' => 'Suburb.suburb_name ASC'));
		   $arrSuburb = array();
		if (count($suburbs) > 0)
		{
			foreach ($suburbs as $suburb)
			{
				$arrSuburb[$suburb['Suburb']['id']] = $suburb['Suburb']['suburb_name'];
			}
		}
		
		$this->set('suburbs', $arrSuburb);
		
		$cities = $this->Area->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		   $arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		
		$this->set('cities', $arrCity);

		
		
		$this->request->data = $area;  
	 
	}
	
	public function view($id = null) {
		if (!$id) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$area = $this->Area->findById($id);
		
		if (!$area) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$this->set('area', $area);
			//$this->request->data = $city;
	
	
	
		   $suburbs = $this->Area->Suburb->find('all', array('order' => 'Suburb.suburb_name ASC'));
		   $arrSuburb = array();
		if (count($suburbs) > 0)
		{
			foreach ($suburbs as $suburb)
			{
				$arrSuburb[$suburb['Suburb']['id']] = $suburb['Suburb']['suburb_name'];
			}
		}
		
		$this->set('suburbs', $arrSuburb);
		
		
		$cities = $this->Area->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		$this->set('cities', $arrCity);

		
		
		
		$this->request->data = $area;  
	 
	}

function get_list_by_suburb(){
	
		$this->layout = 'ajax';
		$suburb_id = $this->request->data['Project']['suburb_id'];
		$areas = $this->Area->find('list', array('conditions' => array('Area.suburb_id' => $suburb_id), 'fields' => 'Area.id, Area.area_name', 'order' => 'Area.area_name ASC'));
		//pr($projects);
		$this->set('areas', $areas);
	}
	
	

function get_list_by_suburb_for_builder(){
	
		$this->layout = 'ajax';
		$suburb_id = $this->request->data['Builder']['suburb_id'];
		$areas = $this->Area->find('list', array('conditions' => array('Area.suburb_id' => $suburb_id), 'fields' => 'Area.id, Area.area_name', 'order' => 'Area.area_name ASC'));
		//pr($projects);
		$this->set('areas', $areas);
	}

}