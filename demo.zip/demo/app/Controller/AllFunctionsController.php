<?php

/**
 * Allfunctions controller.
 *
 * This file will render views from views/departments/
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('AppController', 'Controller');

/**
 * AllFunctions controller contains the list of the commons function through out the site.
 *
 *
 * @package       app.Controller
 */
class AllFunctionsController extends AppController {

    var $uses = array('Project','City','Builder','User','Channel','LookupValueAmenitie','Suburb','Area','LookupValueReimbursementType_2');

    /**
     * Get DeparmentUniversity ID and Department NAME using AJAX POST method
     *
     * @param integer $unv_id This is the university id
     * @param string $model This is the Name of the Model
     * @return null    This method does not return any data.
     * @access public 
     */
    public function get_project() {
        $this->layout = 'ajax';
        $city_id = $this->data['city_id'];
        $model = $this->data['model'];
        $conditions = array('Project.city_id' => $city_id);
        $projects = $this->Project->find('list', array(
            'fields' => array('Project.id', 'Project.project_name'),
            'joins' => array(
                array(
                    'table' => 'cities',
                    'alias' => 'City',
                    'conditions' => array(
                        'City.id = Project.city_id'
                    )
                )
            ),
            'conditions' => $conditions,
            'order' => 'Project.project_name ASC'
        ));
               
        $this->set(compact('projects'));
        $this->set('model', $model);
    }
    
    public function get_prmember_by_channel_id() {
        $this->layout = 'ajax';
    
	$dummy_status = $this->Auth->user('dummy_status');
	$channel_id = $this->data['channel_id'];
    $model = $this->data['model'];
	
	$users = $this->User->find('all',array('fields' => array('User.id','User.fname','User.mname','User.lname','User.company_email_id','User.primary_mobile_number'),
                                                         'conditions' => array('User.exu_channel_id' => $channel_id,'User.exu_role_id' => '7','User.dummy_status' => $dummy_status)));

	//$channels = Set::combine($users, '{n}.User.id',array('%s %s %s','{n}.User.fname','{n}.User.mname','{n}.User.lname'));
	
	
	
	//pr($users);
	
	
	
	$this->set(compact('users'));
                
	$this->set('model', $model);
    }
    public function get_amenity_by_groupId() {
        $this->layout = 'ajax';
        $group_id = $this->data['group_id'];
        $model = $this->data['model'];
        
        $groups = $this->LookupValueAmenitie->find('list', array('fields' => array('LookupValueAmenitie.id', 'LookupValueAmenitie.amenity_name'),
            'conditions' => 'LookupValueAmenitie.group_id =' . $group_id,
            'order' => 'LookupValueAmenitie.amenity_name ASC'));
		$this->set(compact('groups'));
                $this->set('model', $model);
    }
    
    public function get_suburb_by_city($model = null){
	$this->layout = 'ajax';
	
		if($model)
	   		 $city_id = $this->data[$model]['city_id'];
		else
			 $city_id = $this->data['Lead']['city_id'];
	

        $suburbs = $this->Suburb->find('list', array(
            'conditions' => array(
                'Suburb.city_id' => $city_id
            ),
            'fields' => 'Suburb.id, Suburb.suburb_name',
            'order' => 'Suburb.suburb_name ASC'
        ));
        $this->set(compact('suburbs'));
    }

    public function get_area_by_city($model = null){
	$this->layout = 'ajax';
	
	if($model)
		$city_id = $this->data[$model]['city_id'];
	else
		$city_id = $this->data['Lead']['city_id'];	
	
	
    
        $areas = $this->Area->find('list', array(
            'conditions' => array(
                'Area.city_id' => $city_id,
		
            ),
            'fields' => 'Area.id, Area.area_name',
            'order' => 'Area.area_name ASC'
        ));
        $this->set(compact('areas'));
    }
    
    public function get_area_by_suburb($model = null){
	$this->layout = 'ajax';
	
	$city_id = $this->data[$model]['city_id'];
	if($model == 'Lead')
	    $suburb_id = $this->data[$model]['lead_suburb1'];
	else if($model == 'Project')
	     $suburb_id = $this->data[$model]['suburb_id'];	

	if($city_id){
        $areas = $this->Area->find('list', array(
            'conditions' => array(
                'Area.city_id' => $city_id,
		'Area.suburb_id' => $suburb_id
		
            ),
            'fields' => 'Area.id, Area.area_name',
            'order' => 'Area.area_name ASC'
        ));
	}
	else{
	    $areas = $this->Area->find('list', array(
            'conditions' => array(
               
		'Area.suburb_id' => $suburb_id
		
            ),
            'fields' => 'Area.id, Area.area_name',
            'order' => 'Area.area_name ASC'
        ));
	}
	
        $this->set(compact('areas'));
    }
    
    public function get_phone_office_by_cityid(){
	$this->layout = 'ajax';
        $city_id = $this->data['Lead']['city_id'];
		$dummy_status = $this->Auth->user('dummy_status');
        $Channels = $this->Channel->find('all', array(
            'conditions' => array(
                'Channel.city_id' => $city_id,
		'Channel.channel_role' => 5,     // 5 for phone office of lookup_value_channel_roles
		'Channel.dummy_status' => $dummy_status
		
            ),
            'fields' => 'Channel.id, Channel.channel_name',
            'order' => 'Channel.channel_name ASC'
        ));

	  foreach($Channels as $val){
	  	$channel_id[] = $val['Channel']['id'];
	  }

		
		$phone_officer = $this->User->find('all',array('fields' => array('User.id','User.fname','User.mname','User.lname'),'conditions' => array(
		'User.phone_role_id' => 14,     // 14 for phone office of roles table
		'User.phone_channel_id' => $channel_id,
		'User.dummy_status' => $dummy_status
			
		    ),));

		$phone_officer = Set::combine($phone_officer, '{n}.User.id',array('%s %s %s','{n}.User.fname','{n}.User.mname','{n}.User.lname'));
		
        $this->set(compact('phone_officer'));
    }
    public function get_builder_by_cityid($model){
	$this->layout = 'ajax';
	if($model == 'Project')
	     $city_id = $this->data['Project']['city_id'];
	else     
	    $city_id = $this->data['Lead']['city_id'];
       
        $builders = $this->Builder->find('list', array(
	    
	    'conditions' => array('OR' =>array(
                'Builder.builder_primarycity' => $city_id,
		'Builder.builder_secondarycity' => $city_id,
		'Builder.builder_tertiarycity' => $city_id,
		'Builder.city_4' => $city_id,
		'Builder.city_5' => $city_id,
		)
		
		
            ),
            'fields' => 'Builder.id, Builder.builder_name',
            'order' => 'Builder.builder_name ASC'
        ));
        $this->set(compact('builders'));
    }
    
     public function get_type_2_by_type1_id(){
	$this->layout = '';
	 $type_id = $this->data['type_id'];
        $model = $this->data['model'];
      
        $reimbursement_type2 = $this->LookupValueReimbursementType_2->find('list', array(
	    
	    'conditions' => array(
                'type_id' => $type_id,
		
		
            ),
            'fields' => 'id, value',
            'order' => 'value ASC'
        ));
	//pr($reimbursement_type2);
	
        $this->set(compact('reimbursement_type2'));
	$this->set(compact('model'));
    }
	
	public function get_channel_by_city_id(){
	$this->layout = '';
	$city_id = $this->data['User']['city_id'];
      
        $channels = $this->Channel->find('list', array(
	    
	    'conditions' => array(
                'city_id' => $city_id,
		
		
            ),
            'fields' => 'id, channel_name',
            'order' => 'channel_name ASC'
        ));
	//pr($reimbursement_type2);
	
        $this->set(compact('channels'));
	
    }
	
	 public function get_phoneofficer_by_city_id() {
       	$this->layout = 'ajax';
        $city_id = $this->data['Lead']['city_id'];
		$dummy_status = $this->Auth->user('dummy_status');
        $phone_officer = $this->Channel->find('first', array(
            'conditions' => array(
                'Channel.city_id' => $city_id,
		'Channel.channel_role' => 5,     // 5 for phone office of lookup_value_channel_roles
		'Channel.dummy_status' => $dummy_status
		
            ),
            'fields' => 'Channel.channel_name',
            'order' => 'Channel.channel_name ASC'
        ));
		
        $this->set(compact('phone_officer'));
    }
	
	 public function get_project_by_level() {
       	$this->layout = 'ajax';
        $level_id = $this->data['level_id'];
		 $builder_id = $this->data['builder_id'];
		$dummy_status = $this->Auth->user('dummy_status');
		if($level_id == '2')
			 $contact_city = $this->data['contact_city'];
			 
			 
		$projects = array();
		if($level_id == '1')
		{
		
		$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => array('Project.builder_id' => $builder_id)));
	//	$global_project = Set::combine($projects, '{n}.Project.id',array('%s, %s, %s','{n}.Project.project_name','{n}.City.city_name','{n}.Area.area_name'));

		}
		elseif($level_id == '2')
		{
		
		$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => 
		array('Project.city_id' => $contact_city,'OR' => array('Project.builder_id' => $builder_id,'Project.tertiary_builder_id' => $builder_id,'Project.builder_agreement_id' => $builder_id))));
		//$global_project = Set::combine($projects, '{n}.Project.id',array('%s, %s, %s','{n}.Project.project_name','{n}.City.city_name','{n}.Area.area_name'));

		}
		elseif($level_id == '3' || $level_id == '4' || $level_id == '5')
		{
			$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => 
		array('OR' => array('Project.builder_id' => $builder_id,'Project.tertiary_builder_id' => $builder_id,'Project.builder_agreement_id' => $builder_id))));
	//	$global_project = Set::combine($projects, '{n}.Project.id',array('%s, %s, %s','{n}.Project.project_name','{n}.City.city_name','{n}.Area.area_name'));	
		}
		

		
		$this->set('projects',$projects);

       
    }
	
	public function get_associate_by_cityid() {
       	$this->layout = 'ajax';
        $city_id = $this->data['Lead']['city_id'];
		$dummy_status = $this->Auth->user('dummy_status');
		
$associate = $this->User->find('all',array('fields' => array('User.id','User.fname','User.lname'),
                                                         'conditions' => array('User.distributor_role_id' => 5,'User.dummy_status' => $dummy_status,'User.city_id' => $city_id)));

		$associate = Set::combine($associate, '{n}.User.id',array('%s %s','{n}.User.fname','{n}.User.lname'));
				
        $this->set(compact('associate'));
    }
}
