<?php

/*
 * Controller/EventsController.php
 * CakePHP Full Calendar Plugin
 *
 * Copyright (c) 2010 Silas Montgomery
 * http://silasmontgomery.com
 *
 * Licensed under MIT
 * http://www.opensource.org/licenses/mit-license.php
 */

class EventsController extends AppController {

    var $components = array('Session');
    var $helpers = array('Html', 'Form', 'Session', 'Js' => array('Jquery'));
    var $uses = array('Event', 'Project','Lead','Channel','Area','Suburb' ,'City','Builder','LookupValueActivityLevel','LookupValueActivityType');
    var $name = 'Events';
    var $paginate = array(
        'limit' => 15
    );

    function index($pointer = NULL) {
	
	
		$channel_id = $this->Session->read("channel_id");
        $channels = $this->Channel->findById($channel_id);
		$channel_role = $channels['Channel']['channel_role'];
		
       	$self_id = $this->Auth->user("id");
		$city_id = $this->Auth->user("city_id");
       // if (in_array($self_id, array('1', '2', '3', '4', '5'))) {
            $projects = $this->Project->find('list', array('fields' => array('id', 'project_name'),'conditions' => array('city_id' => $city_id),'order' => 'project_name ASC'));
            $this->set(compact('projects'));

            $builders = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name','conditions' => array('OR' => array('builder_primarycity' => $city_id,'builder_secondarycity' => $city_id, 'builder_tertiarycity' => $city_id,'city_4' => $city_id, 'city_5' => $city_id)), 'order' => 'Builder.builder_name ASC'));
            $this->set('builders', $builders);
			
			// $log = $this->Builder->getDataSource()->getLog(false, false);       
      	    // debug($log);
			
			 $channel = $this->Channel->find('list', array('fields' => array('id', 'channel_name'),'conditions' => array('city_id' => $city_id,'channel_role' => $channel_role),'order' => 'channel_name ASC'));
            $this->set(compact('channel'));
			
			$all_cities = $this->City->find('list',array('fields' => 'id,city_name','order' => 'city_name ASC'));
			$this->set(compact('all_cities'));
			//pr($all_cities);
			
			// $log = $this->City->getDataSource()->getLog(false, false);       
      	    // debug($log);
			
			if($city_id <> 1)
				$cities = $this->City->find('list',array('fields' => 'id,city_name','conditions' => array('id' => $city_id),'order' => 'city_name ASC'));
			else
				$cities = $this->City->find('list',array('fields' => 'id,city_name','conditions' => array('NOT' => array('id' =>$city_id)),'order' => 'city_name ASC'));
			$this->set(compact('cities'));
		
		
			$suburbs = $this->Suburb->find('list', array('fields' => array('id', 'suburb_name'),'conditions' => array('city_id' => $city_id),'order' => 'suburb_name ASC'));
            $this->set(compact('suburbs'));
			
	    $user_name = array($this->Auth->user("fname").' '.$this->Auth->user("lname"));
	    $this->set(compact('user_name'));
	    
	    
	    $areas = $this->Area->find('list', array('fields' => array('id', 'area_name'),'conditions' => array('city_id' => $city_id),'order' => 'area_name ASC'));
            $this->set(compact('areas'));

			
			$clients = $this->Lead->find('all',array('fields' => array('Lead.id','Lead.lead_fname','Lead.lead_lname'),'order' => 'Lead.lead_fname ASC'));    
			$clients = Set::combine($clients, '{n}.Lead.id',array('%s %s','{n}.Lead.lead_fname','{n}.Lead.lead_lname'));
            $this->set('clients', $clients);
      //  }

        // Step-1: Get the list of next 7 days
        $start = new DateTime();
        $end = new DateTime();
        if (isset($_SESSION['start_point'])) {
            if ($pointer == "prev") {
                $st = $_SESSION['start_point'] - 7;
                $en = $_SESSION['start_point'];
            } else if ($pointer == "next") {
                $st = $_SESSION['start_point'] + 7;
                $en = $_SESSION['start_point'] + 14;
            } else {
                $st = "0";
                $en = "+20";
            }
        } else {
            $st = "0";
            $en = "+20";
        }
       // echo 'ss='.$en;
        $start = $start->modify($st . ' days');
        $end = $end->modify($en . ' days'); // Date Period doesn't include the end date

        $_SESSION['start_point'] = $st;
        $dates = array();
        $dates_labels = array();
        for ($p = $st; $p < $en; $p++) {
            $day = date('Y-m-d', strtotime($p . ' days'));
            $dates[] = $day;


            $day2 = date('d/m', strtotime($p . ' days'));
            $dates_labels[] = strftime("%A", strtotime($day)) .' '.strftime("%b", strtotime($day)). "-" . strftime("%d", strtotime($day));
        }
        
        $this->set('dates', $dates);
        $this->set('dates_labels', $dates_labels);

        $this->Event->recursive = 1;       
        $activity_levels = $this->LookupValueActivityLevel->find('list',array('fields' => 'id,value','order' => 'id ASC'));
		
		
        $this->set('activity_levels', $activity_levels);
        $events = $this->Event->find('all', array('conditions' => array('DATE(Event.start_date)' => $dates, 'Event.user_id' => $self_id), 'order' => 'Event.start_date, Event.description'));
        $activity_types = $this->LookupValueActivityType->find('list',array('fields' => 'id,value','order' => 'id ASC'));
        $this->set('activity_types', $activity_types);
        
		
	$times = array('00:00:00' => '12.00 AM', '00:15:00' => '12.15 AM','00:30:00' => '12:30 AM','00:45:00' => '12:45 AM', '01:00:00' => '01.00 AM', '01:15:00' => '01.15 AM', '01:30:00' => '01.30 AM', '01:45:00' => '01.45 AM',
		       '02:00:00' => '02.00 AM', '02:15:00' => '02.15 AM', '02:30:00' => '02.30 AM', '02:45:00' => '02.45 AM', '03:00:00' => '03.00 AM', '03:15:00' => '03.15 AM', '03:30:00' => '03.30 AM', '03:45:00' => '03.45 AM', '04:00:00' => '04.00 AM', '04:15:00' => '04.15 AM', '04:30:00' => '04.30 AM', '04:45:00' => '04.45 AM', '05:00:00' => '05.00 AM', '05:15:00' => '05.15 AM', '05:30:00' => '05.30 AM', '05:45:00' => '05.45 AM', '06:00:00' => '06.00 AM', '06:15:00' => '06.15 AM', '06:30:00' => '06.30 AM', '06:45:00' => '06.45 AM', '07:00:00' => '07.00 AM', '07:15:00' => '07.15 AM', '07:30:00' => '07.30 AM', '07:45:00' => '07.45 AM', '08:00:00' => '08.00 AM', '08:15:00' => '08.15 AM', '08:30:00' => '08.30 AM', '08:45:00' => '08.45 AM', '09:00:00' => '09.00 AM', '09:15:00' => '09.15 AM', '09:30:00' => '09.30 AM', '09:45:00' => '09.45 AM', '10:00:00' => '10.00 AM', '10:15:00' => '10.15 AM', '10:30:00' => '10.30 AM', '10:45:00' => '10.45 AM', '11:00:00' => '11.00 AM', '11:15:00' => '11.15 AM', '11:30:00' => '11.30 AM', '11:45:00' => '11.45 AM', '12:00:00' => '12.00 PM', '12:15:00' => '12.15 PM', '12:30:00' => '12.30 PM', '12:45:00' => '12.45 PM', '13:00:00' => '01.00 PM', '13:15:00' => '01.15 PM', '13:30:00' => '01.30 PM', '13:45:00' => '01.45 PM', '14:00:00' => '02.00 PM', '14:15:00' => '02.15 PM', '14:30:00' => '02.30 PM', '14:45:00' => '02.45 PM', '15:00:00' => '03.00 PM', '15:15:00' => '03.15 PM', '15:30:00' => '03.30 PM', '15:45:00' => '03.45 PM', '16:00:00' => '04.00 PM', '16:15:00' => '04.15 PM', '16:30:00' => '04.30 PM', '16:45:00' => '04.45 PM', '17:00:00' => '05.00 PM', '17:15:00' => '05.15 PM', '17:30:00' => '05.30 PM', '17:45:00' => '05.45 PM', '18:00:00' => '06.00 PM', '18:15:00' => '06.15 PM', '18:30:00' => '06.30 PM', '18:45:00' => '06.45 PM', '19:00:00' => '07.00 PM', '19:15:00' => '07.15 PM', '19:30:00' => '07.30 PM', '19:45:00' => '07.45 PM', '20:00:00' => '08.00 PM', '20:15:00' => '08.15 PM', '20:30:00' => '08.30 PM', '20:45:00' => '08.45 PM', '21:00:00' => '09.00 PM', '21:15:00' => '09.15 PM', '21:30:00' => '09.30 PM', '21:45:00' => '09.45 PM', '22:00:00' => '10.00 PM', '22:15:00' => '10.15 PM', '22:30:00' => '10.30 PM', '22:45:00' => '10.45 PM', '23:00:00' => '11.00 PM', '23:15:00' => '11.15 PM', '23:30:00' => '11.30 PM', '23:45:00' => '11.45 PM');
        $this->set('times', $times);
        $this->set('events', $events);
    }

    function add() {
        
        $months = array('Jan' => '01', 'Feb' => '02', 'Mar' => '03', 'Apr' => '04', 'May' => '05', 'Jun' => '06', 'Jul' => '07', 'Aug' => '08', 'Sep' => '09', 'Oct' => '10', 'Nov' => '11', 'Dec' => '12');
        $self_id = $this->Auth->user("id");

        if (!empty($this->data)) {
             
				if($this->data['Event']['activity_past'] == 'Yes'){
					$start_datepart = $this->request->data['Event']['event_date_past'];
				}
				else{
					$start_datepart = $this->request->data['Event']['event_date_present'];
				}
			
               // $start_datepart = $this->data['Event']['start_datepart'];
                // Todo: Check  date validity
                $dd = substr($start_datepart, 0, 2);
                $mon = substr($start_datepart, 3, 3);
                $mm = $months[$mon];
                $yyyy = substr($start_datepart, 7, 4);
                $this->Event->create();
                $this->request->data['Event']['start_date'] = $yyyy . "-" . $mm . "-" . $dd . " " . $this->data['Event']['start_time'];
                $this->request->data['Event']['end_date'] = $yyyy . "-" . $mm . "-" . $dd . " " . $this->data['Event']['end_time'];
                $this->request->data['Event']['creator_id'] = $self_id;
                $this->request->data['Event']['user_id'] = $self_id;
                $this->request->data['Event']['project_id'] = $this->data['Event']['project_id'];
                $this->request->data['Event']['builder_id'] = $this->data['Event']['builder_id'];
                $this->request->data['Event']['active'] = 1;

                if ($this->Event->save($this->data)) {
                    $this->Session->setFlash(__('The event has been saved', true), 'success');
                    $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__('The event could not be saved. Please, try again.', true), 'error');
                }
           
        }
    }
    
    function edit($id = NULL){
        $this->layout = '';
        $events = $this->Event->findById($id);
        if ($this->request->is('post') || $this->request->is('put')) {
	    $this->request->data['Event']['start_date'] = $this->data['Event']['date'].' '.$this->data['Event']['start_time'];
	     $this->request->data['Event']['end_date'] = $this->data['Event']['date'].' '.$this->data['Event']['end_time'];
	   
            $this->Event->id = $id;
            $this->Event->set($this->data);
            if ($this->Event->validates() == true) {
                if ($this->Event->save($this->request->data)) {
                    $this->Session->write('success_msg', 'Event has been updated.');                
                    echo '<script>parent.$.fancybox.close(); parent.location.reload(true);exit();</script>';
                } else {
                    $this->Session->setFlash(__('Unable to update department.'), 'default', array('class' => 'alert_error'));
                    return $this->redirect(array('controller' => 'departments', 'action' => 'add', 'admin' => true));
                }
            }
        }
	
	
	$start_date = $events['Event']['start_date'];
	$saart_arr = explode(' ',$start_date);
	$start_date = $saart_arr[0];
	$start_time = $saart_arr[1];
	
	$this->set(compact('start_date'));
	$this->set(compact('start_time'));
	
	$end_date = $events['Event']['end_date'];
	$end_arr = explode(' ',$end_date);
	
	$end_time = $end_arr[1];
    
	$this->set(compact('end_time'));
	
	$times = array('00:00:00' => '12.00 AM', '00:15:00' => '12.15 AM','00:30:00' => '12:30 AM','00:45:00' => '12:45 AM', '01:00:00' => '01.00 AM', '01:15:00' => '01.15 AM', '01:30:00' => '01.30 AM', '01:45:00' => '01.45 AM',
		       '02:00:00' => '02.00 AM', '02:15:00' => '02.15 AM', '02:30:00' => '02.30 AM', '02:45:00' => '02.45 AM', '03:00:00' => '03.00 AM', '03:15:00' => '03.15 AM', '03:30:00' => '03.30 AM', '03:45:00' => '03.45 AM', '04:00:00' => '04.00 AM', '04:15:00' => '04.15 AM', '04:30:00' => '04.30 AM', '04:45:00' => '04.45 AM', '05:00:00' => '05.00 AM', '05:15:00' => '05.15 AM', '05:30:00' => '05.30 AM', '05:45:00' => '05.45 AM', '06:00:00' => '06.00 AM', '06:15:00' => '06.15 AM', '06:30:00' => '06.30 AM', '06:45:00' => '06.45 AM', '07:00:00' => '07.00 AM', '07:15:00' => '07.15 AM', '07:30:00' => '07.30 AM', '07:45:00' => '07.45 AM', '08:00:00' => '08.00 AM', '08:15:00' => '08.15 AM', '08:30:00' => '08.30 AM', '08:45:00' => '08.45 AM', '09:00:00' => '09.00 AM', '09:15:00' => '09.15 AM', '09:30:00' => '09.30 AM', '09:45:00' => '09.45 AM', '10:00:00' => '10.00 AM', '10:15:00' => '10.15 AM', '10:30:00' => '10.30 AM', '10:45:00' => '10.45 AM', '11:00:00' => '11.00 AM', '11:15:00' => '11.15 AM', '11:30:00' => '11.30 AM', '11:45:00' => '11.45 AM', '12:00:00' => '12.00 PM', '12:15:00' => '12.15 PM', '12:30:00' => '12.30 PM', '12:45:00' => '12.45 PM', '13:00:00' => '01.00 PM', '13:15:00' => '01.15 PM', '13:30:00' => '01.30 PM', '13:45:00' => '01.45 PM', '14:00:00' => '02.00 PM', '14:15:00' => '02.15 PM', '14:30:00' => '02.30 PM', '14:45:00' => '02.45 PM', '15:00:00' => '03.00 PM', '15:15:00' => '03.15 PM', '15:30:00' => '03.30 PM', '15:45:00' => '03.45 PM', '16:00:00' => '04.00 PM', '16:15:00' => '04.15 PM', '16:30:00' => '04.30 PM', '16:45:00' => '04.45 PM', '17:00:00' => '05.00 PM', '17:15:00' => '05.15 PM', '17:30:00' => '05.30 PM', '17:45:00' => '05.45 PM', '18:00:00' => '06.00 PM', '18:15:00' => '06.15 PM', '18:30:00' => '06.30 PM', '18:45:00' => '06.45 PM', '19:00:00' => '07.00 PM', '19:15:00' => '07.15 PM', '19:30:00' => '07.30 PM', '19:45:00' => '07.45 PM', '20:00:00' => '08.00 PM', '20:15:00' => '08.15 PM', '20:30:00' => '08.30 PM', '20:45:00' => '08.45 PM', '21:00:00' => '09.00 PM', '21:15:00' => '09.15 PM', '21:30:00' => '09.30 PM', '21:45:00' => '09.45 PM', '22:00:00' => '10.00 PM', '22:15:00' => '10.15 PM', '22:30:00' => '10.30 PM', '22:45:00' => '10.45 PM', '23:00:00' => '11.00 PM', '23:15:00' => '11.15 PM', '23:30:00' => '11.30 PM', '23:45:00' => '11.45 PM');
        $this->set('times', $times);
	
	
        
	$channel_id = $this->Session->read("channel_id");
	$channels = $this->Channel->findById($channel_id);
		$channel_role = $channels['Channel']['channel_role'];
		
       	$self_id = $this->Auth->user("id");
		$city_id = $this->Auth->user("city_id");
      //  if (in_array($self_id, array('1', '2', '3', '4', '5'))) {
            $projects = $this->Project->find('list', array('fields' => array('id', 'project_name'),'conditions' => array('city_id' => $city_id),'order' => 'project_name ASC'));
            $this->set(compact('projects'));

            $builders = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name','conditions' => array('OR' => array('builder_primarycity' => $city_id,'builder_secondarycity' => $city_id, 'builder_tertiarycity' => $city_id,'city_4' => $city_id, 'city_5' => $city_id)), 'order' => 'Builder.builder_name ASC'));
            $this->set('builders', $builders);
			
			 $channel = $this->Channel->find('list', array('fields' => array('id', 'channel_name'),'conditions' => array('city_id' => $city_id,'channel_role' => $channel_role),'order' => 'channel_name ASC'));
            $this->set(compact('channel'));
			
			$all_cities = $this->City->find('list',array('fields' => 'id,city_name','order' => 'city_name ASC'));
			$this->set(compact('all_cities'));
			
			if($city_id <> 1)
				$cities = $this->City->find('list',array('fields' => 'id,city_name','conditions' => array('id' => $city_id),'order' => 'city_name ASC'));
			else
				$cities = $this->City->find('list',array('fields' => 'id,city_name','conditions' => array('NOT' => array('id' =>$city_id)),'order' => 'city_name ASC'));
			$this->set(compact('cities'));
		
		
			$suburbs = $this->Suburb->find('list', array('fields' => array('id', 'suburb_name'),'conditions' => array('city_id' => $city_id),'order' => 'suburb_name ASC'));
            $this->set(compact('suburbs'));
			
			$user_name = array($this->Auth->user("fname").' '.$this->Auth->user("lname"));
			$this->set(compact('user_name'));
			
			
			$areas = $this->Area->find('list', array('fields' => array('id', 'area_name'),'conditions' => array('city_id' => $city_id),'order' => 'area_name ASC'));
            $this->set(compact('areas'));

			
			$clients = $this->Lead->find('all',array('fields' => array('Lead.id','Lead.lead_fname','Lead.lead_lname'),'order' => 'Lead.lead_fname ASC'));    
			$clients = Set::combine($clients, '{n}.Lead.id',array('%s %s','{n}.Lead.lead_fname','{n}.Lead.lead_lname'));
            $this->set('clients', $clients);
			
       // }
		$activity_levels = $this->LookupValueActivityLevel->find('list',array('fields' => 'id,value','order' => 'id ASC'));
       
        $this->set('activity_levels', $activity_levels);
		 $activity_types = $this->LookupValueActivityType->find('list',array('fields' => 'id,value','order' => 'id ASC'));
     //   $activity_types = array(1 => 'Call', 2 => 'Email', 3 => 'Follow up', 4 => 'Meeting', 5 => 'Site Visit', 6 => 'Property Fair');
        $this->set('activity_types', $activity_types);
        if (!$this->request->data) {
        $this->request->data = $events;
         }
    }
	
    function view($id = NULL){
        $this->layout = '';
	$flag = 0;
	$cur_date = date('Y-m-d h:i:s');
	
        $events = $this->Event->findById($id);

	 $self_id = $this->Auth->user("id");
	 
	 if($cur_date > $events['Event']['end_date'] && $events['Event']['activity_completed'] == '2') //2 for no of lookup_value_statuses
	    $flag = 1;
	if($cur_date > $events['Event']['end_date'] && $events['Event']['activity_completed'] == '1')  //1 for yes of lookup_value_statuses
	 $flag = 2;
	 
	 $this->set(compact('flag'));
	    
	
       // if (in_array($self_id, array('1', '2', '3', '4', '5'))) {
            $projects = $this->Project->find('list', array('fields' => array('id', 'project_name')));
            $this->set(compact('projects'));

            $builders = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name', 'order' => 'Builder.builder_name ASC'));
            $this->set('builders', $builders);
      //  }
        $activity_levels = $this->LookupValueActivityLevel->find('list',array('fields' => 'id,value','order' => 'id ASC'));
        $this->set('activity_levels', $activity_levels);
        $activity_types = $this->LookupValueActivityType->find('list',array('fields' => 'id,value','order' => 'id ASC'));
        $this->set('activity_types', $activity_types);
        if (!$this->request->data) {
        $this->request->data = $events;
         }
    }

}

?>
