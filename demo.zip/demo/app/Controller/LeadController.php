<?php
class LeadController extends AppController {

	public $uses = array('Lead', 'Builder','Role','Channel', 'Area','LookupValueLeadsCountry','LookupValueLeadsClosureProbability', 'Suburb','City','Unit','Project','Channel','ActionItemType','LeadStatus','LookupValueLeadsCategory','LookupValueLeadsCreationType','LookupValueLeadsImportance','LookupValueLeadsIndustry','LookupValueLeadsProgress','LookupValueLeadsSegment','LookupValueLeadsType','LookupValueLeadsUrgency','LookupValueProjectUnitType','ActionItem','LookupValueLeadsSource','LookupValueLeadsCurrency','LookupValueProjectPhase','LookupValueLeadsCreationType','User','Remark','ActionItemLevel','LookupValueActionItemStatus','LookupValueLeadsProgress');
	public $components = array('Sms');

	public function index()
	{
		$dummy_status = $this->Auth->user('dummy_status');  
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		$user_id = $this->Auth->user('id');
		$city_id = $this->Auth->user('city_id');
		$role_id = $this->Session->read("role_id");
		$roles = $this->Role->find('all',array('conditions' => 'Role.id = '.$role_id));
		
		$role_name = $roles[0]['GroupsUser']['name'];
		
        $search_condition = array();
		$user_con = array();
		
		if ($this->request->is('post') || $this->request->is('put')) {
	
           if (!empty($this->data['Lead']['global_search'])) {
				$search = $this->data['Lead']['global_search'];         
				array_push($search_condition, array('OR' => array('Lead.lead_fname' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%", 'Project.project_name' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%", 'Builder.builder_name' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%")));
		    }	
		     if (!empty($this->data['Lead']['city_id'])) {
			 $search = $this->data['Lead']['city_id'];
			array_push($search_condition, array('Lead.city_id' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['builder_id'])) {
			 $search = $this->data['Lead']['builder_id'];
			array_push($search_condition, array('Lead.builder_id1' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['project_id'])) {
			 $search = $this->data['Lead']['project_id'];
			array_push($search_condition, array('Lead.proj_id1' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['unit_id'])) {
			 $search = $this->data['Lead']['unit_id'];
			array_push($search_condition, array('Lead.lead_unit_id_1' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_country'])) {
			 $search = $this->data['Lead']['lead_country'];
			array_push($search_condition, array('Lead.lead_country' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_urgency'])) {
			 $search = $this->data['Lead']['lead_urgency'];
			array_push($search_condition, array('Lead.lead_urgency' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_importance'])) {
			 $search = $this->data['Lead']['lead_importance'];
			array_push($search_condition, array('Lead.lead_importance' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_status'])) {
			 $search = $this->data['Lead']['lead_status'];
			array_push($search_condition, array('Lead.lead_status' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_suburb1'])) {
			 $search = $this->data['Lead']['lead_suburb1'];
			array_push($search_condition, array('Lead.lead_suburb1' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_areapreference1'])) {
			 $search = $this->data['Lead']['lead_areapreference1'];
			array_push($search_condition, array('Lead.lead_areapreference1' => mysql_escape_string(trim(strip_tags($search)))));
		     }
                     if (!empty($this->data['Lead']['lead_channel'])) {
			 $search = $this->data['Lead']['lead_channel'];
			array_push($search_condition, array('Lead.lead_channel' => mysql_escape_string(trim(strip_tags($search)))));
		     }
		     if (!empty($this->data['Lead']['lead_closureprobabilityinnext1Month'])) {
			 $search = $this->data['Lead']['lead_closureprobabilityinnext1Month'];
			array_push($search_condition, array('Lead.lead_closureprobabilityinnext1Month' => $search));
		     }
		     if (!empty($this->data['Lead']['lead_managerprimary'])) {
			 $search = $this->data['Lead']['lead_managerprimary'];
			array_push($search_condition, array('Lead.lead_managerprimary' => $search));
		     }
		     if (!empty($this->data['Lead']['lead_managersecondary'])) {
			 $search = $this->data['Lead']['lead_managersecondary'];
			array_push($search_condition, array('Lead.lead_managersecondary' => $search));
		     }
		     if (!empty($this->data['Lead']['lead_associate'])) {
			 $search = $this->data['Lead']['lead_associate'];
			array_push($search_condition, array('Lead.lead_associate' => $search));
		     }
		     if (!empty($this->data['Lead']['lead_phoneofficer'])) {
			 $search = $this->data['Lead']['lead_phoneofficer'];
			array_push($search_condition, array('Lead.lead_phoneofficer' => $search));
		     }
		     
		}
		if($role_name === 'Execution'){
			array_push($search_condition, array('OR' => array('Lead.lead_managerprimary' => $user_id,'Lead.lead_managersecondary' => $user_id)));
			$user_con = array('User.city_id' => $city_id,'User.dummy_status' => $dummy_status);
		}
		elseif($role_name === 'Phone Officer'){
			array_push($search_condition, array('Lead.lead_phoneofficer' => $user_id));
			$user_con = array('User.city_id' => $city_id,'User.dummy_status' => $dummy_status);
		}
		elseif($role_name === 'Associate'){
			array_push($search_condition, array('Lead.lead_associate' => $user_id));
		}

		elseif($city_id > 1){
			array_push($search_condition, array('Lead.city_id' => $city_id));
			
		}
		if($dummy_status)
			array_push($search_condition, array('Lead.dummy_status' => $dummy_status));
		$leads = $this->paginate("Lead", $search_condition);
		$this->set(compact('leads'));
		
		//$log = $this->Lead->getDataSource()->getLog(false, false);       
		//debug($log);
			
		$city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' => $condition_dummy_status, 'order' => 'City.city_name ASC'));
		$this->set('city', $city);
		
		$led_type = $this->LookupValueLeadsType->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('led_type'));		

			 
		$project = $this->Project->find('list', array('fields' => 'Project.id, Project.project_name','conditions' => $condition_dummy_status, 'order' => 'Project.project_name ASC'));
		$this->set('project', $project);			
			
		$builder = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name','conditions' => $condition_dummy_status, 'order' => 'Builder.builder_name ASC'));
		$this->set('builder', $builder);
		
		$unit = $this->LookupValueProjectUnitType->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set('unit', $unit);
		
		$country = $this->LookupValueLeadsCountry->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('country'));
		
		$status = $this->LeadStatus->find('list',array('fields' => array('id','status')));
		$this->set(compact('status'));
		
		$importance = $this->LookupValueLeadsImportance->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('importance'));
		
		$urgencies = $this->LookupValueLeadsUrgency->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('urgencies'));
		
		$suburbs = $this->Suburb->find('list', array('fields' => 'Suburb.id, Suburb.suburb_name','conditions' => $condition_dummy_status, 'order' => 'Suburb.suburb_name ASC'));
		$this->set(compact('suburbs'));

		$areas = $this->Area->find('list', array('fields' => 'Area.id, Area.area_name','conditions' => $condition_dummy_status, 'order' => 'Area.area_name ASC'));
		$this->set('areas', $areas);
		
		$channels = $this->Channel->find('list', array('fields' => 'id, channel_name','conditions' => $condition_dummy_status, 'order' => 'channel_name ASC'));
		$this->set('channels', $channels);
		
		$segment = $this->LookupValueLeadsSegment->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('segment'));
		
		$closureprobabilities = $this->LookupValueLeadsClosureProbability->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('closureprobabilities'));
		
	
		
		$common_user = $this->User->find('all',array('fields' => array('User.id','User.fname','User.lname'),
                                                        'conditions' => $user_con,'order' => 'User.fname asc'));

		$common_user = Set::combine($common_user, '{n}.User.id',array('%s %s','{n}.User.fname','{n}.User.lname'));
		$this->set(compact('common_user'));	 
		
	}	
	
	public function add() {
		//$this->layout = 'ajax';
		$dummy_status = $this->Auth->user('dummy_status');
		$this->set(compact('dummy_status'));
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		$user_id = $this->Auth->User('id');
		$city_id = $this->Auth->User('city_id');
		$phone_officer =array();
		$phone_value = '';
		$creation_default_value = '';
		$associate =array();

		$role_id = $this->Session->read("role_id");
		$roles = $this->Role->find('all',array('conditions' => 'Role.id = '.$role_id));
		
		
		$creation_type = $roles[0]['GroupsUser']['name'];
		
		$this->set(compact('creation_type'));
		
		
		
		$conditions = '';
		$city_conditions = '';
		$phone_coditions = '';
		$id = 'phone_officer_id';
		if($creation_type == 'Administrator' || $creation_type == 'System Admin')
		{
			//$conditions = array('NOT' => array('value' => array('Administrator','System Admin')));
			$city_conditions = array('dummy_status' => $dummy_status);
			
		}
		elseif($creation_type == 'Associate')
		{
			$conditions = array('value' => $creation_type);
			$id = 'phone_officer_id';
			$city_conditions = array('dummy_status' => $dummy_status);
			$creation_default_value = '4';
		
			
			$associate = $this->User->find('all',array('fields' => array('User.id','User.fname','User.lname'),
                                                         'conditions' => array('User.id' => $user_id)));

		$associate = Set::combine($associate, '{n}.User.id',array('%s %s','{n}.User.fname','{n}.User.lname'));
		}
		elseif($creation_type == 'Phone Officer')
		{
			$conditions = array('value' => $creation_type);
			$city_conditions = array('id' => $city_id);
			$phone_coditions = array('city_id' => $city_id);
			$creation_default_value = '1';
			
			
			$phone_officer = $this->User->find('all',array('fields' => array('User.id','User.fname','User.mname','User.lname'),'conditions' => array(
               // 'User.city_id' => $phone_coditions,
		'User.id' => $user_id,     // 14 for phone office of roles table
		
		
		
			
		    ),));

		$phone_officer = Set::combine($phone_officer, '{n}.User.id',array('%s %s %s','{n}.User.fname','{n}.User.mname','{n}.User.lname'));
		foreach($phone_officer as $phone_val){
			 $phone_value = $phone_val;
			
		}
		
		
		
	
		}
		elseif($creation_type == 'Execution')
		{
			
			$city_conditions = array('dummy_status' => $dummy_status);
			
		}
		else{
			
			$city_conditions = array('dummy_status' => $dummy_status);
			
		
		}
	
		$this->set(compact('associate'));
		$this->set(compact('phone_value'));
		$this->set(compact('creation_default_value'));
		
		if ($this->request->is('post')) {
		
		$next_action_by = '';
	
		
			$business_admin = $this->Channel->find('first',array('conditions' => array('Channel.city_id' => $this->data['Lead']['city_id'],'Channel.channel_role' => '13','Channel.dummy_status' => $dummy_status)));  // business admin logic. 13 for business admin of lookup_value_channel_roles table
		
		if(!empty($business_admin))	{
		$next_action_id = $this->User->find('first',array('conditions' => array('User.business_admin_channel_id' => $business_admin['Channel']['id'],'User.business_admin_role_id' => 4,'User.dummy_status'=> $dummy_status))); // 4 for business admin of roles table	
			
			if(!empty($next_action_id)){
				$next_action_by = $next_action_id['User']['id'];
			}
		
		}

			
		$this->request->data['Lead']['created_by'] = $user_id;
		$this->request->data['Lead']['dummy_status'] = $dummy_status;
		$this->request->data['Lead']['lead_sandboxed'] = 'No';
		$this->request->data['Lead']['lead_progress'] = '1'; // 1 for Fresh Client of lookup_value_leads_progresses
		$this->request->data['Lead']['lead_travel_potential'] = '1'; // 1 for yes of  lookup_value_statuses
		$this->request->data['Lead']['lead_loan_potential'] = '1';   // ,,
		$this->request->data['Lead']['lead_insurance_potential'] = '2';  // 2 for no of lookup_value_statuses
		$this->request->data['Lead']['lead_pwm_potential'] = '2';  // 2 for no of lookup_value_statuses
		$this->request->data['Lead']['lead_email_subscription'] = '1'; // 1 for yes of  lookup_value_statuses
		$this->request->data['Lead']['lead_email_id_for_subscription'] = $this->data['Lead']['lead_emailid'];
		$this->request->data['Lead']['lead_special_client_status'] = '2';   // 2 for no of lookup_value_statuses
		$this->request->data['Lead']['lead_multicity_status'] = '2';   // 2 for no of lookup_value_statuses

		   // $this->Lead->create();
		    $this->Lead->set($this->data);
		     if ($this->Lead->validates() == true) {
			if ($this->Lead->save($this->request->data)) {
			    $lead_id = $this->Lead->getLastInsertId();
			    $actionitem['ActionItem']['lead_id'] = $lead_id;
			    $actionitem['ActionItem']['action_item_level_id'] = '1'; // 1 for client
			    $actionitem['ActionItem']['type_id'] = '1'; // 1 for waiting for allocation
				 $actionitem['ActionItem']['next_action_by'] = $next_action_by;
			    $actionitem['ActionItem']['action_item_active'] = 'Yes';
			    $actionitem['ActionItem']['action_item_status'] = '1'; //1 for created table - lookup_value_action_item_statuses
			    $actionitem['ActionItem']['description'] = 'New Client Record Created - Waiting For Allocation';
			    $actionitem['ActionItem']['action_item_source'] = $role_id;			
				$actionitem['ActionItem']['created_by_id'] = $user_id;
			    $actionitem['ActionItem']['created_by'] = $user_id;
			    $actionitem['ActionItem']['dummy_status'] = $dummy_status;
			    
			    $remarks['Remark']['lead_id'] = $lead_id;
			    $remarks['Remark']['remarks'] = 'New Client Record Created';
			    $remarks['Remark']['remarks_by'] = $user_id;
			    $remarks['Remark']['remarks_level'] = '3'; //3 for client from lookup_value_remarks_level
			    $remarks['Remark']['dummy_status'] = '2';
			    $this->ActionItem->save($actionitem);
			    $ActionId = $this->ActionItem->getLastInsertId();
			    $this->ActionItem->id = $ActionId;
			    $this->ActionItem->saveField('parent_action_item_id' , $ActionId);
			    $this->Remark->save($remarks);
			    
			    $this->Session->setFlash('Your new client record has been created. Waiting for allocation at the moment.','success');
		    	
			    $this->redirect(array('controller' => 'messages','action' => 'index','lead','my-clients'));
			} else {
			    $this->Session->setFlash('Unable to add Lead.','failure');
			}
		     }
        }
       	
		$city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' => $city_conditions, 'order' => 'City.city_name ASC'));
		
		$this->set('city', $city);
		
		
		
		
		
		
		//$codes = $this->LookupValueLeadsCountry->find('list', array('fields' => 'id,code', 'order' => 'code ASC'));
		$this->set(compact('phone_officer'));
		
		// $log = $this->User->getDataSource()->getLog(false, false);       
        // debug($log);
		
		/*
		
		 $phone_officer = $this->User->find('list', array('conditions' => array(
                'User.city_id' => $phone_coditions,
		'User.phone_role_id' => 14,     // 14 for phone office of roles table
		'User.dummy_status' => $dummy_status
			
		    ),
		    'fields' => 'Channel.id, Channel.channel_name',
		    'order' => 'Channel.channel_name ASC'
		));
		
		$this->set(compact('phone_officer'));
		*/
		//$log = $this->Channel->getDataSource()->getLog(false, false);       
		//debug($log);
		$this->set(compact('id'));
		
		$builders = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name','conditions' => $condition_dummy_status, 'order' => 'Builder.builder_name ASC'));
		
		$this->set('builders', $builders);

		$projects = $this->Lead->Project->find('list', array('fields' => 'Project.id, Project.project_name','conditions' => $condition_dummy_status ,'order' => 'Project.project_name ASC'));
		$this->set('projects', $projects);
		
		$suburbs = $this->Suburb->find('list', array('fields' => 'Suburb.id, Suburb.suburb_name','conditions' => $condition_dummy_status, 'order' => 'Suburb.suburb_name ASC'));
		$this->set(compact('suburbs'));

		$areas = $this->Area->find('list', array('fields' => 'Area.id, Area.area_name','conditions' => $condition_dummy_status, 'order' => 'Area.area_name ASC'));
		$this->set('areas', $areas);
		
		$units = $this->LookupValueProjectUnitType->find('list', array('fields' => 'LookupValueProjectUnitType.id, LookupValueProjectUnitType.value', 'order' => 'LookupValueProjectUnitType.value ASC'));
		$this->set('unit', $units);
		
		$types = $this->LookupValueLeadsType->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('types'));
		
		$status = $this->LeadStatus->find('list',array('fields' => array('id','status')));
		$this->set(compact('status'));
		
		$categories = $this->LookupValueLeadsCategory->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('categories'));
		
		$industry = $this->LookupValueLeadsIndustry->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('industry'));
		$segment = $this->LookupValueLeadsSegment->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('segment'));
		
		$importance = $this->LookupValueLeadsImportance->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('importance'));
		
		$urgencies = $this->LookupValueLeadsUrgency->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('urgencies'));
		
		$lead_progrss = $this->LookupValueLeadsProgress->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('lead_progrss'));
		
		$countires = $this->LookupValueLeadsCountry->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('countires'));
		
		$codes = $this->LookupValueLeadsCountry->find('all',array('fields' => array('LookupValueLeadsCountry.id','LookupValueLeadsCountry.value','LookupValueLeadsCountry.code')));

		$codes = Set::combine($codes, '{n}.LookupValueLeadsCountry.id',array('%s: %s','{n}.LookupValueLeadsCountry.value','{n}.LookupValueLeadsCountry.code'));
		
		
		//$codes = $this->LookupValueLeadsCountry->find('list', array('fields' => 'id,code', 'order' => 'code ASC'));
		$this->set(compact('codes'));
		
		$closureprobabilities = $this->LookupValueLeadsClosureProbability->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('closureprobabilities'));
		
		$channel_name = $this->Channel->find('list', array('fields' => 'Channel.id, Channel.channel_name','conditions' => $condition_dummy_status, 'order' => 'Channel.channel_name ASC'));
		$this->set('channel_name', $channel_name);
		
		$source = $this->LookupValueLeadsSource->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('source'));
		
		$courrency = $this->LookupValueLeadsCurrency->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('courrency'));
		
		$type_preference = $this->LookupValueProjectPhase->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('type_preference'));
		
		$creation_types = $this->LookupValueLeadsCreationType->find('list', array('fields' => 'id, value','conditions' => $conditions, 'order' => 'value ASC'));
		$this->set(compact('creation_types'));
	
		
		
		
		
		$created_by = $this->User->find('all',array('fields' => array('User.id','User.fname','User.lname'),
                                                         'conditions' => array('User.id' => $user_id)));

		$created_by = Set::combine($created_by, '{n}.User.id',array('%s %s','{n}.User.fname','{n}.User.lname'));
		$this->set(compact('created_by'));
			

		}
		
	/*$builders = $this->Lead->Builder->find('all', array('order' => 'Builder.builder_name ASC'));
		$arrBuilder = array();
		if (count($builders) > 0)
		{
			foreach ($builders as $builder)
			{
				$arrBuilder[$builder['Builder']['id']] = $builder['Builder']['builder_name'];
			}
		}
		
		$this->set('builders', $arrBuilder);

	}*/

	
	/*$cities = $this->Suburb->City->find('all', array('order' => 'City.city_name ASC'));
		$arrCity = array();
		if (count($cities) > 0)
		{
			foreach ($cities as $city)
			{
				$arrCity[$city['City']['id']] = $city['City']['city_name'];
			}
		}
		
		$this->set('citiess', $arrCity);
	}
	*/
	
 function edit($id = null)
	 {
	 
	 	$id = base64_decode($id);
		
		if (!$id) 	{
						throw new NotFoundException(__('Invalid Lead'));
					}
	
		$lead = $this->Lead->findById($id);
		
	//	echo $lead['Lead']['lead_status'] ;
		if($lead['Lead']['lead_status'] <> '4'){
		 $this->redirect(array('controller' => 'lead','action' => 'view','slug' => $lead['Lead']['lead_fname'].'-'.$lead['Lead']['lead_lname'].'-'.$lead['City']['city_name'],'id' => base64_encode($id)));
			
		}
		
		
		
		if (!$lead) {
				throw new NotFoundException(__('Invalid Lead'));
			}
		
		$city_id = $this->Auth->User('city_id');
		
		$role_id = $this->Session->read("role_id");
		$roles = $this->Role->find('all',array('conditions' => 'Role.id = '.$role_id));
		
		
		$creation_type = $roles[0]['GroupsUser']['name'];
		
		$conditions = '';
		$city_conditions = '';
		$phone_coditions = '';
		$phone_officer_id = 'phone_officer_id';
		
		if($creation_type == 'Administrator' || $creation_type == 'System Admin')
		{
			$conditions = array('NOT' => array('value' => array('Administrator','System Admin')));
		}
		elseif($creation_type == 'Associate')
		{
			$conditions = array('value' => $creation_type);
			$phone_officer_id = 'associate_id';
		}
		elseif($creation_type == 'Phone Officer')
		{
			$conditions = array('value' => $creation_type);
			$city_conditions = array('id' => $city_id);
			$phone_coditions = array('city_id' => $city_id);
			
		}
		
		$user_id = $this->Auth->User('id');
		
		
	
		if ($this->request->data) 
		{
		
			$this->Lead->set($this->data);
			 if ($this->Lead->validates() == true) {
				$this->Lead->id = $id;
				if ($this->Lead->save($this->request->data)) 
					{
						$this->Session->setFlash('Your client record has been updated.','success');
						 $this->redirect(array('controller' => 'messages','action' => 'index','lead','my-clients'));
						//$this->redirect(array('action' => 'index'));
					} 
				else 
					{
						$this->Session->setFlash('Unable to update Lead.','failure');
					}
			 }
		}
			
		$city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' => $city_conditions, 'order' => 'City.city_name ASC'));
		
		$this->set('city', $city);
		
		$phone_officer = $this->User->find('all',array('fields' => array('User.id','User.fname','User.mname','User.lname'),'conditions' => array('User.id' => $lead['Lead']['lead_phoneofficer'])));
		$phone_officer = Set::combine($phone_officer, '{n}.User.id',array('%s %s %s','{n}.User.fname','{n}.User.mname','{n}.User.lname'));		

		
		$this->set(compact('phone_officer'));
		$this->set(compact('phone_officer_id'));
		
		$builders = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name', 'order' => 'Builder.builder_name ASC'));
		
		$this->set('builders', $builders);

		$projects = $this->Lead->Project->find('list', array('fields' => 'Project.id, Project.project_name', 'order' => 'Project.project_name ASC'));
		$this->set('projects', $projects);
		
		$suburbs = $this->Suburb->find('list', array('fields' => 'Suburb.id, Suburb.suburb_name', 'order' => 'Suburb.suburb_name ASC'));
		$this->set(compact('suburbs'));

		$areas = $this->Area->find('list', array('fields' => 'Area.id, Area.area_name', 'order' => 'Area.area_name ASC'));
		$this->set('areas', $areas);
		
		$codes = $this->LookupValueLeadsCountry->find('all',array('fields' => array('LookupValueLeadsCountry.id','LookupValueLeadsCountry.value','LookupValueLeadsCountry.code')));
		$codes = Set::combine($codes, '{n}.LookupValueLeadsCountry.id',array('%s: %s','{n}.LookupValueLeadsCountry.value','{n}.LookupValueLeadsCountry.code'));		
		$this->set(compact('codes'));
		
		$lead_progrss = $this->LookupValueLeadsProgress->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('lead_progrss'));
		
		$action_level = $this->ActionItemLevel->find('list',array('fields' => array('id','level')));
		$this->set(compact('action_level'));
		
		$action_type = $this->ActionItemType->find('list',array('fields' => array('id','type')));
		$this->set(compact('action_type'));
		
		$action_status = $this->LookupValueActionItemStatus->find('list',array('fields' => array('id','value')));
		$this->set(compact('action_status'));
		
		$units = $this->LookupValueProjectUnitType->find('list', array('fields' => 'LookupValueProjectUnitType.id, LookupValueProjectUnitType.value', 'order' => 'LookupValueProjectUnitType.value ASC'));
		$this->set('unit', $units);
		
		$status = $this->LeadStatus->find('list',array('fields' => array('id','status')));
		$this->set(compact('status'));
		
		$countires = $this->LookupValueLeadsCountry->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('countires'));
		
		$closureprobabilities = $this->LookupValueLeadsClosureProbability->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('closureprobabilities'));
		
		$urgencies = $this->LookupValueLeadsUrgency->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('urgencies'));
		
		$importance = $this->LookupValueLeadsImportance->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('importance'));
		
		$types = $this->LookupValueLeadsType->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('types'));
		
		$categories = $this->LookupValueLeadsCategory->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('categories'));
		
		$channel_name = $this->Channel->find('list', array('fields' => 'Channel.id, Channel.channel_name', 'order' => 'Channel.channel_name ASC'));
		$this->set('channel_name', $channel_name);
		
		$industry = $this->LookupValueLeadsIndustry->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('industry'));
		$segment = $this->LookupValueLeadsSegment->find('list', array('fields' => 'id,value', 'order' => 'value ASC'));
		$this->set(compact('segment'));
		
		$source = $this->LookupValueLeadsSource->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('source'));
		
		$courrency = $this->LookupValueLeadsCurrency->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('courrency'));
		
		$type_preference = $this->LookupValueProjectPhase->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('type_preference'));
		
		$creation_types = $this->LookupValueLeadsCreationType->find('list', array('fields' => 'id, value','conditions' => $conditions, 'order' => 'value ASC'));
		$this->set(compact('creation_types'));	
		
		$created_by = $this->User->find('all',array('fields' => array('User.id','User.fname','User.lname')));

		$created_by = Set::combine($created_by, '{n}.User.id',array('%s %s','{n}.User.fname','{n}.User.lname'));
		$this->set(compact('created_by'));

		$this->request->data = $lead;
			
		
	}
	
	function view($id = null){
               
            $id = base64_decode($id);
	
		if (!$id) 	{
						throw new NotFoundException(__('Invalid Lead'));
					}
	
		$lead = $this->Lead->findById($id);
		
		if (!$lead) {
				throw new NotFoundException(__('Invalid Lead'));
			}
		
		$created_by = $this->User->find('all',array('fields' => array('User.id','User.fname','User.lname')));

		$created_by = Set::combine($created_by, '{n}.User.id',array('%s %s','{n}.User.fname','{n}.User.lname'));
		$this->set(compact('created_by'));
		
		$action_level = $this->ActionItemLevel->find('list',array('fields' => array('id','level')));
		$this->set(compact('action_level'));
		
		$action_type = $this->ActionItemType->find('list',array('fields' => array('id','type')));
		$this->set(compact('action_type'));
		
		$action_status = $this->LookupValueActionItemStatus->find('list',array('fields' => array('id','value')));
		$this->set(compact('action_status'));
		
		$source = $this->LookupValueLeadsSource->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
		$this->set(compact('source'));

		$this->request->data = $lead;
			
	}
	function send_text($id) {
		$leads = $this->Lead->find('all',array('conditions' => array('Lead.id' => $id)));
		
		$html = 'City-'.$leads['City']['city_name'].',Urgency-'.$leads['City']['city_name'];
		pr($leads);
		die;
		$authKey = Configure::read('sms_api_key');
		$senderId = Configure::read('sms_sender_id');	
		$mobileNumber = "9433657552";
		$message = urlencode("Hiii");
		$route = "default";		
		$this->Sms->send_sms($authKey,$mobileNumber,$message,$senderId,$route);
	
       }
       
       function get_list_by_country_code(){
	$this->layout = 'ajax';
        $country_id = $this->data['Lead']['lead_country'];

        $codes = $this->LookupValueLeadsCountry->find('list', array(
            'conditions' => array(
                'LookupValueLeadsCountry.id' => $country_id
            ),
            'fields' => 'LookupValueLeadsCountry.id, LookupValueLeadsCountry.code',
            'order' => 'LookupValueLeadsCountry.code ASC'
        ));
	 /// $log = $this->LookupValueLeadsCountry->getDataSource()->getLog(false, false);       
//debug($log);
	 
        $this->set('codes',$codes);
	
       }
	
	
}