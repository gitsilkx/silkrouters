<?php
class BuilderController extends AppController {

       public $uses = array('Builder', 'Area', 'Suburb', 'City','LookupBuilderAgreementLevel','LookupBuilderAgreementProposed','LookupBuilderAgreementManagedBy','LookupBuilderAgreementIntiatedBy','LookupBuilderAgreementPreparedBy','LookupBuilderAgreementCommissionBasedOn','LookupBuilderAgreementCommissionTerm','LookupValueLeadsCountry','BuilderAgreement','BuilderContact','LookupBuilderContactStatus','ActionItem','Project','ProjectAgreement','Channel','User','LookupBuilderContactLevel','LookupBuilderContactInitiatedBy','LookupBuilderContactManagedBy','LookupBuilderContactPreparedBy');      
	 
    public function index() {
       
       $dummy_status = $this->Auth->user('dummy_status');
           
       $city_id = $this->Auth->user('city_id');
        
        $search_condition = array();
        $search = '';
        if ($this->request->is('post') || $this->request->is('put')) {
            if (!empty($this->data['Builder']['builder_name'])) {
                $search = $this->data['Builder']['builder_name'];
                array_push($search_condition, array('Builder.builder_name' . ' LIKE' => mysql_escape_string(trim(strip_tags($search))) . "%"));
             }
             if (!empty($this->data['Builder']['builder_highendresidential'])) {
                $search = $this->data['Builder']['builder_highendresidential'];
                array_push($search_condition, array('Builder.builder_highendresidential' =>$search));
            } 
           
            if (!empty($this->data['Builder']['builder_primarycity'])) {
                $search = $this->data['Builder']['builder_primarycity'];
                array_push($search_condition, array('Builder.builder_primarycity'  =>$search));
            }
            if (!empty($this->data['Builder']['builder_residential'])) {
                $search = $this->data['Builder']['builder_residential'];
                array_push($search_condition, array('Builder.builder_residential' => $search));
            }
            if (!empty($this->data['Builder']['builder_commercial'])) {
                $search = $this->data['Builder']['builder_commercial'];
                array_push($search_condition, array('Builder.builder_commercial' => $search));
            } 
        } 
         if($city_id > 1){
               array_push($search_condition, array('OR' => array('Builder.builder_primarycity' => $city_id,'Builder.builder_secondarycity' => $city_id,'Builder.builder_tertiarycity' => $city_id,'Builder.city_4' => $city_id,'Builder.city_5' => $city_id)));
         }
         
         if($dummy_status){
               array_push($search_condition, array('Builder.dummy_status' => $dummy_status));
              
         }

        $this->paginate['order'] = array('Builder.builder_name' => 'asc');
        $this->set('builders', $this->paginate("Builder", $search_condition));

        $builder = $this->Builder->find('list', array('fields' => 'Builder.id, Builder.builder_name', 'order' => 'Builder.builder_name ASC'));
        $this->set('builder', $builder);
        
         //$log = $this->Builder->getDataSource()->getLog(false, false);       
         //debug($log);

        $city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' => array('City.dummy_status' => $dummy_status), 'order' => 'City.city_name ASC'));
        $this->set('city', $city);

        
    }

    public function add() {
	
		$user_id = $this->Auth->user('id');
		$role_id = $this->Session->read("role_id");
		$dummy_status = $this->Auth->user('dummy_status');

        if ($this->request->is('post')) {
		

			$this->request->data['Builder']['dummy_status'] = $dummy_status;
		

			
		
            $this->Builder->create();
            if ($this->Builder->save($this->request->data)) {
			
				$builder_id = $this->Builder->getLastInsertId();
				if($builder_id){
				
				
				$this->Session->setFlash('Builder has been saved.', 'success');
				$this->redirect(array('action' => 'agreement',$builder_id));
				
	
				}   
               
            } else {
                $this->Session->setFlash('Unable to add builder.', 'failure');
            }
        }

        $city = $this->City->find('list', array('fields' => 'City.id, City.city_name', 'order' => 'City.city_name ASC'));
        $this->set('city', $city);

        $suburb = $this->Suburb->find('list', array('fields' => 'Suburb.id, Suburb.suburb_name', 'order' => 'Suburb.suburb_name ASC'));
        $this->set('suburbs', $suburb);

        $areas = $this->Area->find('list', array('fields' => 'Area.id, Area.area_name', 'order' => 'Area.area_name ASC'));
        $this->set('areas', $areas);

		
		
		
    }

  
    function edit($id = null) {
	
		$user_id = $this->Auth->user('id');
		$role_id = $this->Session->read("role_id");
		$dummy_status = $this->Auth->user('dummy_status');
		
        $id = base64_decode($id);
        
        if (!$id) {
            throw new NotFoundException(__('Invalid Builder'));
        }

        $builder = $this->Builder->findById($id);

        if (!$builder) {
            throw new NotFoundException(__('Invalid builder'));
        }

        if ($this->request->data) {
		
			$agreement_id = $this->data['Agreement']['agreement_id'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_builder_id'] = $id;
			$BuilderAgreement['BuilderAgreement']['builder_agreement_level'] = $this->data['Agreement']['builder_agreement_level'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_proposed_by'] = $this->data['Agreement']['builder_agreement_proposed_by'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_marketing_partner_id'] = $this->data['Agreement']['builder_agreement_marketing_partner_id'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_company'] = $this->data['Agreement']['builder_agreement_company'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_company_city'] = $this->data['Agreement']['builder_agreement_company_city'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_managed_by'] = $this->data['Agreement']['builder_agreement_managed_by'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_managed_by_id'] = $this->data['Agreement']['builder_agreement_managed_by_id'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_prepared_by'] = $this->data['Agreement']['builder_agreement_prepared_by'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_prepared_by_id'] = $this->data['Agreement']['builder_agreement_prepared_by_id'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_name'] = $this->data['Agreement']['builder_agreement_contact_name'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_designation'] = $this->data['Agreement']['builder_agreement_contact_designation'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_email'] = $this->data['Agreement']['builder_agreement_contact_email'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_primary_mobile_code'] = $this->data['Agreement']['builder_agreement_contact_primary_mobile_code'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_primary_mobile'] = $this->data['Agreement']['builder_agreement_contact_primary_mobile'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_secondary_mobile_code'] = $this->data['Agreement']['builder_agreement_contact_secondary_mobile_code'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_secondary_mobile'] = $this->data['Agreement']['builder_agreement_contact_secondary_mobile'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_lan_country_code'] = $this->data['Agreement']['builder_agreement_lan_country_code'];
			$BuilderAgreement['BuilderAgreement']['builder_agreement_lan_no'] = $this->data['Agreement']['builder_agreement_lan_no'];
			
			$BuilderAgreement['BuilderAgreement']['builder_agreement_contact_address'] = $this->data['Agreement']['builder_agreement_contact_address'];
			$BuilderAgreement['BuilderAgreement']['dummy_status'] = $dummy_status;
			
		
			$this->request->data['BuilderContact']['builder_contact_builder_id'] = $id;
			$this->request->data['BuilderContact']['dummy_status'] = $dummy_status;
			$contact_id = $this->data['BuilderContact']['contact_id'];
	
			/***************************Next Action By logic***********************/
			
			$action_user_id = '';
			$oversing_user= array();
			
			$oversing_channel = $this->Channel->find('first',array('conditions' => array('Channel.city_id'=> $this->data['BuilderContact']['builder_contact_company_city'],'Channel.dummy_status' => $dummy_status),'fields' => 'id'));
			
			if(!empty($oversing_channel))
			$oversing_user = $this->User->find('first',array('conditions' => array('User.overse_channel_id'=> $oversing_channel['Channel']['id'],'User.overse_role_id' => 10,'User.dummy_status' => $dummy_status),'fields' => 'id')); // 10 for Overseer of roles table.
			
			if(count($oversing_user))
				$action_user_id = $oversing_user['User']['id'];
			
			/***************************Builder Agreement Action ***********************/
			$builder_id = $id;
			$action_item_level_id = '6'; //  for Builder Agreement
			$type_id = '10'; // 10 for Re-Submission For Approval
			// $actionitem['ActionItem']['next_action_by'] = $business_admin['Channel']['id'];
			$action_item_active = 'Yes';
			$action_item_status = '1'; //1 for created table - lookup_value_action_item_statuses
			$description = 'New Buillder Record Created - Re-Submission For Approval';
			$action_item_source = $role_id;			
			$created_by_id = $user_id;
			$created_by = $user_id;
			$dummy_status = $dummy_status;
			$next_action_by = $action_user_id;
			$action_id = $this->data['ActionItemBuilder']['action_id'];
			
			/***************************Project Agreement Action ***********************/
			$ProjectActionitem['ActionItem']['action_item_level_id'] = '8'; //  for Project Agreement
			$ProjectActionitem['ActionItem']['type_id'] = '10'; // 10 for Re-Submission For Approval
			$ProjectActionitem['ActionItem']['next_action_by'] = $action_user_id;
			$ProjectActionitem['ActionItem']['action_item_active'] = 'Yes';
			$ProjectActionitem['ActionItem']['action_item_status'] = '1'; //1 for created table - lookup_value_action_item_statuses
			$ProjectActionitem['ActionItem']['description'] = 'New Project Agreement Record Created - Re-Submission For Approval';
			$ProjectActionitem['ActionItem']['action_item_source'] = $role_id;			
			$ProjectActionitem['ActionItem']['created_by_id'] = $user_id;
			$ProjectActionitem['ActionItem']['created_by'] = $user_id;
			$ProjectActionitem['ActionItem']['dummy_status'] = $dummy_status;
			
			/***********************Project Agreement *********************************/
			
			if($this->Project->find('count',array('conditions' => array('Project.builder_id' => $id,'Project.dummy_status' => $dummy_status))))
					$project_agreement_done_with  = '1'; // primary builder of lookup_project_agreement_done_withs
			else if($this->Project->find('count',array('conditions' => array('Project.secondary_builder_id' => $id,'Project.dummy_status' => $dummy_status))))
					$project_agreement_done_with  = '2'; // secondary builder of lookup_project_agreement_done_withs
			else if($this->Project->find('count',array('conditions' => array('Project.tertiary_builder_id' => $id,'Project.dummy_status' => $dummy_status))))
					$project_agreement_done_with  = '3'; // tertiary builder of lookup_project_agreement_done_withs		
	
			$formatted_prog_agree = Hash::extract($builder['ProjectAgreement'], '{n}.project_agreement_project_id');
			
            $db_req = array_diff($formatted_prog_agree, $this->request->data['ProjectAgreement']['project_agreement_project_id']);
			$req_db = array_diff($this->request->data['ProjectAgreement']['project_agreement_project_id'], $formatted_prog_agree);
			
			$save = array(); $saved = 0;
						
						
						
				if (!empty($db_req)) {
                    foreach ($db_req as $project_id) {
                        $del = $this->ProjectAgreement->deleteAll(
                                array(
                            'ProjectAgreement.project_agreement_project_id' => $project_id,
                            'ProjectAgreement.project_agreement_builder_id' => $id,
							'ProjectAgreement.dummy_status' => $dummy_status,
							
                                ), false);
                        if ($del) $save = $saved = 1;
                    }
                }
                
                if (!empty($req_db)) {
                    $save = array();
                    foreach ($req_db as $project_id) {
					
                        $save = array('ProjectAgreement' => array(
                                'project_agreement_project_id' => $project_id,
                                'project_agreement_builder_id' => $id,
								'project_agreement_done_with' => $project_agreement_done_with,
								'dummy_status' => $dummy_status,
								
                        ));
						$this->ProjectAgreement->saveMany($save);
						$ProjectActionitem['ActionItem']['project_id'] = $project_id;
						$this->ActionItem->saveMany($ProjectActionitem);

                        
                    }
	
                }
			
				//die;
				/******************************End project agreement ***********************************/

				
			
			/*
            if (!empty($project_id)) {
                foreach ($project_id as $project) {
                    $save[] = array('ProjectAgreement' => array(
                            'project_agreement_builder_id' => $id,
                            'project_agreement_project_id' => $project
                    ));
                }
            }
			*/
			
		

            $this->Builder->id = $id;
            if ($this->Builder->save($this->request->data)) {
			
	
				
				
			  if($agreement_id > 0){
				$this->BuilderAgreement->id = $agreement_id;
				
				}
				if(!$action_id){
					$this->ActionItem->query("INSERT INTO action_items (`builder_id`,`action_item_level_id`,`type_id`,`action_item_active`,`action_item_status`,`description`,`action_item_source`,`created_by_id`,`created_by`,`dummy_status`,`next_action_by`) VALUES (".$builder_id.",".$action_item_level_id.",".$type_id.",'".$action_item_active."','".$action_item_status."','".$description."','".$action_item_source."','".$created_by_id."','".$created_by."',".$dummy_status.",'".$next_action_by."')");
				}
				
				if($contact_id > 0){
					$this->BuilderContact->id = $contact_id;
				}
				
			//	$this->ProjectAgreement->saveMany($save);
				$this->BuilderAgreement->save($BuilderAgreement);
			
				$this->BuilderContact->save($this->data['BuilderContact']);
				
				
				
				
				// $this->BuilderAgreement->updateAll($BuilderAgreement,array('BuilderAgreement.id' => $agreement_id));
                $this->Session->setFlash('Builder has been updated.', 'success');
				 $this->redirect(array('controller' => 'messages','action' => 'index','builder','my-builders'));
               // $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash('Unable to update builder.', 'failure');
            }
        }

  		



        $city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' =>array('City.dummy_status' => $dummy_status), 'order' => 'City.city_name ASC'));
        $this->set('city', $city);
		
		$agreement_level = $this->LookupBuilderAgreementLevel->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('agreement_level'));
		
		$agreement_proposed = $this->LookupBuilderAgreementProposed->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('agreement_proposed'));
		
		$manage_by = $this->LookupBuilderAgreementManagedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('manage_by'));
		
		$intiate_by = $this->LookupBuilderAgreementIntiatedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('intiate_by'));
		
		$prepare_by = $this->LookupBuilderAgreementPreparedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('prepare_by'));
		
		$commission_based_on = $this->LookupBuilderAgreementCommissionBasedOn->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('commission_based_on'));
		
		$commission_terms = $this->LookupBuilderAgreementCommissionTerm->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('commission_terms'));
		
		$codes = $this->LookupValueLeadsCountry->find('all',array('fields' => array('LookupValueLeadsCountry.id','LookupValueLeadsCountry.value','LookupValueLeadsCountry.code')));
		$codes = Set::combine($codes, '{n}.LookupValueLeadsCountry.id',array('%s: %s','{n}.LookupValueLeadsCountry.value','{n}.LookupValueLeadsCountry.code'));
		$this->set(compact('codes'));
		
		$contact_status = $this->LookupBuilderContactStatus->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_status'));
		
		$agreement_level_id = $builder['Agreement']['builder_agreement_level'];
		
		if($agreement_level_id == '1')
		{
		
		$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => array('Project.builder_id' => $id)));
	//	$global_project = Set::combine($projects, '{n}.Project.id',array('%s, %s, %s','{n}.Project.project_name','{n}.City.city_name','{n}.Area.area_name'));

		}
		elseif($agreement_level_id == '2')
		{
		
		$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => 
		array('Project.city_id' => $builder['BuilderContact']['builder_contact_company_city'],'OR' => array('Project.builder_id' => $id,'Project.tertiary_builder_id' => $id,'Project.builder_agreement_id' => $id))));
		//$global_project = Set::combine($projects, '{n}.Project.id',array('%s, %s, %s','{n}.Project.project_name','{n}.City.city_name','{n}.Area.area_name'));

		}
		elseif($agreement_level_id == '3' || $agreement_level_id == '4' || $agreement_level_id == '5')
		{
			$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => 
		array('OR' => array('Project.builder_id' => $id,'Project.tertiary_builder_id' => $id,'Project.builder_agreement_id' => $id))));
	//	$global_project = Set::combine($projects, '{n}.Project.id',array('%s, %s, %s','{n}.Project.project_name','{n}.City.city_name','{n}.Area.area_name'));	
		}
		else
		{
		$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name'),'conditions' => array('Project.builder_id' => $id)));
		}

		$this->set(compact('projects'));
		
		$contact_level = $this->LookupBuilderContactLevel->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_level'));
		
		 $city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' =>array('City.dummy_status' => $dummy_status), 'order' => 'City.city_name ASC'));
        $this->set('city', $city);
		
		$codes = $this->LookupValueLeadsCountry->find('all',array('fields' => array('LookupValueLeadsCountry.id','LookupValueLeadsCountry.value','LookupValueLeadsCountry.code')));
		$codes = Set::combine($codes, '{n}.LookupValueLeadsCountry.id',array('%s: %s','{n}.LookupValueLeadsCountry.value','{n}.LookupValueLeadsCountry.code'));
		$this->set(compact('codes'));
		
		$contact_initiated = $this->LookupBuilderContactInitiatedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_initiated'));
		
		$contact_managed = $this->LookupBuilderContactManagedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_managed'));
		
		$contact_prepared = $this->LookupBuilderContactPreparedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_prepared'));
		
		$contact_status = $this->LookupBuilderContactStatus->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_status'));
		
		
		
		//$projects = $this->Project->find('list',array('fields' => array('Project.id','Project.project_name')));
	//	$global_project = Set::combine($projects, '{n}.Project.id',array('%s','{n}.Project.project_name'));
	//	$this->set('projects',$projects);
		/*
		 $log = $this->Project->getDataSource()->getLog(false, false);       
         debug($log);
		die;
		*/
		$proagree = Hash::extract($builder['ProjectAgreement'], '{n}.project_agreement_project_id');
	//	$this->set('selected',$proagree);
		
        $this->request->data = $builder;
		$this->request->data['ProjectAgreement']['project_agreement_project_id'] = $proagree;
		//$this->request->data = $builder_agreement;
    }
	
	public function agreement($builder_id = null){
	
		$dummy_status = $this->Auth->user('dummy_status');
		$user_id = $this->Auth->user('id');
		$role_id = $this->Session->read("role_id");
		
		
		 if ($this->request->is('post')) {
		 
		  if($builder_id){
				$this->request->data['BuilderContact']['builder_contact_builder_id'] = $builder_id;
				$this->request->data['BuilderAgreement']['builder_agreement_builder_id'] = $builder_id;
				$this->request->data['BuilderContact']['dummy_status'] = $dummy_status;
				$this->request->data['BuilderAgreement']['dummy_status'] = $dummy_status;
				
				$actionitem['ActionItem']['builder_id'] = $builder_id;
					$actionitem['ActionItem']['action_item_level_id'] = '2'; // 1 for builder
					$actionitem['ActionItem']['type_id'] = '7'; // 7 for Submission For Approval
					// $actionitem['ActionItem']['next_action_by'] = $business_admin['Channel']['id'];
					$actionitem['ActionItem']['action_item_active'] = 'Yes';
					$actionitem['ActionItem']['action_item_status'] = '1'; //1 for created table - lookup_value_action_item_statuses
					$actionitem['ActionItem']['description'] = 'New Buillder Record Created - Submission For Approval';
					$actionitem['ActionItem']['action_item_source'] = $role_id;			
					$actionitem['ActionItem']['created_by_id'] = $user_id;
					$actionitem['ActionItem']['created_by'] = $user_id;
					$actionitem['ActionItem']['dummy_status'] = $dummy_status;
					
						/***************************Next Action By logic***********************/
			
					$action_user_id = '';
					$oversing_user= array();
					
					$oversing_channel = $this->Channel->find('first',array('conditions' => array('Channel.city_id'=> $this->data['BuilderContact']['builder_contact_company_city'],'Channel.dummy_status' => $dummy_status),'fields' => 'id'));
					
					if(!empty($oversing_channel))
					$oversing_user = $this->User->find('first',array('conditions' => array('User.overse_channel_id'=> $oversing_channel['Channel']['id'],'User.overse_role_id' => 10,'User.dummy_status' => $dummy_status),'fields' => 'id')); // 10 for Overseer of roles table.
					
					if(count($oversing_user))
						$action_user_id = $oversing_user['User']['id'];
						
				// end		
				
				if($this->BuilderContact->save($this->request->data('BuilderContact')) &&  $this->BuilderAgreement->save($this->request->data('BuilderAgreement'))){
					
					$actionitem['ActionItem']['builder_id'] = $builder_id;
					$actionitem['ActionItem']['action_item_level_id'] = '2'; // 1 for builder
					$actionitem['ActionItem']['type_id'] = '7'; // 7 for Submission For Approval
					$actionitem['ActionItem']['next_action_by'] = $action_user_id;
					$actionitem['ActionItem']['action_item_active'] = 'Yes';
					$actionitem['ActionItem']['action_item_status'] = '1'; //1 for created table - lookup_value_action_item_statuses
					$actionitem['ActionItem']['description'] = 'New Buillder Record Created - Submission For Approval';
					$actionitem['ActionItem']['action_item_source'] = $role_id;			
					$actionitem['ActionItem']['created_by_id'] = $user_id;
					$actionitem['ActionItem']['created_by'] = $user_id;
					$actionitem['ActionItem']['dummy_status'] = $dummy_status;
					
					if($this->ActionItem->save($actionitem)){
						$this->Session->setFlash('Builder Contact & Agreement has been updated.', 'success');
						$this->redirect(array('controller' => 'messages','action' => 'index','builder','my-builders'));
					}
					
					
				}
				
			 
			 }
		   else
		   {
		   		 $this->Session->setFlash('Unable to update builder.', 'failure');
				 $this->redirect(array('controller' => 'builder','action' => 'add'));
		   }	 
		 }
		
		$contact_level = $this->LookupBuilderContactLevel->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_level'));
		
		 $city = $this->City->find('list', array('fields' => 'City.id, City.city_name','conditions' =>array('City.dummy_status' => $dummy_status), 'order' => 'City.city_name ASC'));
        $this->set('city', $city);
		
		$codes = $this->LookupValueLeadsCountry->find('all',array('fields' => array('LookupValueLeadsCountry.id','LookupValueLeadsCountry.value','LookupValueLeadsCountry.code')));
		$codes = Set::combine($codes, '{n}.LookupValueLeadsCountry.id',array('%s: %s','{n}.LookupValueLeadsCountry.value','{n}.LookupValueLeadsCountry.code'));
		$this->set(compact('codes'));
		
		$contact_initiated = $this->LookupBuilderContactInitiatedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_initiated'));
		
		$contact_managed = $this->LookupBuilderContactManagedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_managed'));
		
		$contact_prepared = $this->LookupBuilderContactPreparedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_prepared'));
		
		$contact_status = $this->LookupBuilderContactStatus->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('contact_status'));
		
		$agreement_level = $this->LookupBuilderAgreementLevel->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('agreement_level'));
		
		$agreement_proposed = $this->LookupBuilderAgreementProposed->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('agreement_proposed'));
		
		$manage_by = $this->LookupBuilderAgreementManagedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('manage_by'));
		
		$intiate_by = $this->LookupBuilderAgreementIntiatedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('intiate_by'));
		
		$prepare_by = $this->LookupBuilderAgreementPreparedBy->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('prepare_by'));
		
		$commission_based_on = $this->LookupBuilderAgreementCommissionBasedOn->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('commission_based_on'));
		
		$commission_terms = $this->LookupBuilderAgreementCommissionTerm->find('list', array('fields' => 'id, value', 'order' => 'value ASC'));
        $this->set(compact('commission_terms'));
		
		
	}

    function view($id = null) {
	
		 $id = base64_decode($id);
		 
        if (!$id) {
            throw new NotFoundException(__('Invalid Builder'));
        }

        $builder = $this->Builder->findById($id);

        if (!$builder) {
            throw new NotFoundException(__('Invalid builder'));
        }

        $this->request->data = $builder;
    }


    
}

