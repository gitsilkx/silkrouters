<?php
class CityController extends AppController {
	var $uses = array('City','LookupValueStatus');
	
	public $helpers = array('Html', 'Form', 'Session');
	public $components = array('Session');
	

	public function index() {
		
		$dummy_status = $this->Auth->user('dummy_status');
		$condition_dummy_status = array('dummy_status' => $dummy_status);
		$search_condition = array();
		if($dummy_status)	
			 array_push($search_condition, array('City.dummy_status' => $dummy_status));
		
		$this->paginate['order'] = array('City.city_name' => 'asc');
		$this->set('cities', $this->paginate("City", $search_condition));
		
		
	}
	
	public function add() {

		$dummy_status = $this->Auth->user('dummy_status');
		$this->request->data['City']['dummy_status'] = $dummy_status;
		
        if ($this->request->is('post')) {
            $this->City->create();
            if ($this->City->save($this->request->data)) {
                $this->Session->setFlash('City has been saved.','success');
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash('Unable to add city.','failure');
            }
        }	
	}
	
	public function edit($id = null) {
		
		$id = base64_decode($id);
		
		
				
		if (!$id) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$city = $this->City->findById($id);
		
		if (!$city) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		if ($this->request->data) {
			
			$this->City->id = $id;
			if ($this->City->save($this->request->data)) {
				$this->Session->setFlash('City has been updated.','success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Unable to update city.','failure');
			}
		}
		
		$status = $this->LookupValueStatus->find('list',array('fields' => array('id','value')));
		$this->set(compact('status'));
	
		if (!$this->request->data) {
			$this->request->data = $city;
		}
	}
	
	public function view($id = null) {
				
		if (!$id) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$city = $this->City->findById($id);
		
		if (!$city) {
			throw new NotFoundException(__('Invalid City'));
		}
	
		$this->set('city', $city);
	}


}