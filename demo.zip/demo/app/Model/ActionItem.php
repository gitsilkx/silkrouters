<?php
	App::uses('AppModel', 'Model');
	
	class ActionItem extends AppModel 
	{
		public $validate = array(
			
			/*'description' => array(											
			'notempty' => array(									
				'rule' => array('notempty'),								
				'message' => 'Please enter area name',
				
				),
			)
			*/
			);
            
		public $belongsTo = array(
                                     
				      
				      'Lead' => array(
						'className' => 'Lead',
						'foreignKey' => 'lead_id'
				      ),
				      'ActionBuilder' => array(
						'fields' => array('builder_name'),
						'className' => 'Builder',
						'foreignKey' => 'builder_id'
						
							       ),
				      'ActionProject' => array(
						'fields' => array('project_name'),
						'className' => 'Project',
						'foreignKey' => 'project_id'
						
							       ),
				      'Channel' => array(
						'className'    => 'Channel',
						'fields' => array('Channel.channel_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_channel = Channel.id',
					
				    
					    ),
				      'City' => array(
						'className'    => 'City',
						'fields' => array('City.city_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.city_id = City.id',
					
				    
					    ),
				      	'Project' => array(
						'className'    => 'Project',
						'fields' => array('Project.project_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.proj_id1 = Project.id',
					
								
							),
					'Builder' => array(
						'className'    => 'Builder',
						'fields' => array('Builder.builder_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.builder_id1 = Builder.id',
					
								
							),
					'Area' => array(
						'className'    => 'Area',
						'fields' => array('Area.area_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_areapreference1 = Area.id',

						    ),
					'TypeProject' => array(
						'className'    => 'LookupValueProjectUnitType',
						'fields' => array('TypeProject.value'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_typeofprojectpreference1 = TypeProject.id',

						    ),
					'Type' => array(
						'className'    => 'LookupValueProjectPhase',
						'fields' => array('Type.value'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_typeofprojectpreference1 = Type.id',

						    ),		
							
					'Area' => array(
						'className'    => 'Area',
						'fields' => array('Area.area_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_areapreference1 = Area.id',

						    ),
					'Suburb' => array(
						'className'    => 'Suburb',
						'fields' => array('Suburb.suburb_name'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_suburb1 = Suburb.id',

						    ),
					'Unit' => array(
						'className'    => 'LookupValueProjectUnitType',
						
						'foreignKey' => false,
						'conditions' => 'Lead.lead_unit_id_1 = Unit.id',

						    ),
					'Importance' => array(
						'className'    => 'LookupValueLeadsImportance',
						'foreignKey' => false,
						'conditions' => 'Lead.lead_importance = Importance.id',
	
					    ),
					'Urgency' => array(
						'className'    => 'LookupValueLeadsUrgency',
						'foreignKey' => false,
						'conditions' => 'Lead.lead_urgency = Urgency.id',
	
					    ),
					'Country' => array(
						'className'    => 'LookupValueLeadsCountry',
						'foreignKey' => false,
						'conditions' => 'Lead.lead_country = Country.id',
					    
						    ),
					'PrimaryManage' => array(
							'className'    => 'User',
							'fields' => array('PrimaryManage.fname','PrimaryManage.lname'),
							'foreignKey'   => 'primary_manager_id'
							),
					'Associate' => array(
							'className'    => 'User',
							'fields' => array('Associate.fname','Associate.mname','Associate.lname'),
							'foreignKey' => false,
							'conditions' => 'Lead.lead_associate = Associate.id',
							),		
					'NextActionBy' => array(
							'className'    => 'User',
							'fields' => array('NextActionBy.fname','NextActionBy.mname','NextActionBy.lname'),
							'foreignKey'   => 'next_action_by'
							),		
					'SecondaryManage' => array(
							'className'    => 'User',
							'fields' => array('SecondaryManage.fname','SecondaryManage.lname'),
							'foreignKey'   => 'secondary_manager_id'
							),		
					'PhoneOfficer' => array(
						'className'    => 'User',
						'fields' 	=> array('PhoneOfficer.fname','PhoneOfficer.mname','PhoneOfficer.lname'),
						'foreignKey' => false,
						'conditions' => 'Lead.lead_phoneofficer = PhoneOfficer.id',
					    
						    ),		
									 
					'CreatedBy' => array(
						'className' => 'Lead',
						'foreignKey' => 'created_by_id'
				      ),
					'ActionItemLevel' => array(
						'className' => 'ActionItemLevel',
						'foreignKey' => 'action_item_level_id'
					),
					'LeadStatus' => array(
						'className' => 'LeadStatus',
						'foreignKey' => false,
						'conditions' => 'Lead.lead_status = LeadStatus.id',
					
				      ),
					  'ActionType' => array(
						'className' => 'action_item_types',
						'foreignKey' => 'type_id',
						
					
				      ),
					   'Role' => array(
						'className' => 'Role',
						'foreignKey' => 'action_item_source',

				      ),
					   'LastActionBy' => array(
						'className' => 'User',
						'foreignKey' => 'created_by_id',
						
					
				      ),
             );
	    /*
	    public $hasMany = array(
        'Remark' => array('conditions' => array('Remark.lead_id' => 'ActionItem.lead_id'))
     );
     */
	   /*  var $hasMany = array(   
        'Remark' => array(
                    'className' => 'Remark',
                    'foreignKey' => 'lead_id',
		     'joinTable' => 'action_items',
		     'alias' => 'ActionItem',
                    'conditions' => 'ActionItem.lead_id = Remark.lead_id',     

                    )
	);
	*/
	   /* var $hasMany = array(
		'Remark' => array(
		    'className' => 'Remark',
		    'joinTable' => 'action_items',
		    'foreignKey' => 'lead_id',
		    'associationForeignKey' => 'lead_id'
		)
	    );
	    */

        }
?>