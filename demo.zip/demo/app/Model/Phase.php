<?php
	App::uses('AppModel', 'Model');
	
	class Phase extends AppModel {
		var $name = 'Phase';
		
		
	}
?>