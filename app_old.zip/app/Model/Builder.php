<?php
	App::uses('AppModel', 'Model');
	
	class Builder extends AppModel {
		public $name = 'Builder';
		
		public $validate = array(
			'builder_name' => array(
				'Rule1' => array(
					'rule' => array('notempty'),
					'message' => 'Please enter builder name'
				),
				'Rule2' => array(
					'rule' => 'isUnique',
					'message' => 'Builder name already exists',
					'on' => 'create'
				),
			),
			
			
	
			
			
		
);
		
public $belongsTo = array(
       
	'Residental' => array(
            'className'    => 'LookupValueStatus',
            'foreignKey'   => 'builder_residential'
        ),
	'Highend' => array(
            'className'    => 'LookupValueStatus',
            'foreignKey'   => 'builder_highendresidential'
        ),
	'Commercial' => array(
            'className'    => 'LookupValueStatus',
            'foreignKey'   => 'builder_commercial'
        ),
	'City' => array(
	    'fields' => 'city_name',		
            'className'    => 'City',
            'foreignKey'   => 'builder_primarycity'
        ),
	'Agreement' => 	array(
						'className'    => 'BuilderAgreement',
						'foreignKey' => false,
						'conditions' => 'Builder.id = Agreement.builder_agreement_builder_id',

		),

	'BuilderStatus' => 	array(
            'className'    => 'LookupValueStatus',
            'foreignKey'   => 'builder_status'
        ),
	
	'AgreementLevel' =>  array(
						'className'    => 'LookupBuilderAgreementLevel',
						'foreignKey' => false,
						'conditions' => 'Agreement.builder_agreement_level = AgreementLevel.id',

					),
	'ProposedBy' =>  array(
						'className'    => 'LookupBuilderAgreementProposed',
						'foreignKey' => false,
						'conditions' => 'Agreement.builder_agreement_proposed_by = ProposedBy.id',

					),	
	'AgreementCity' =>  array(
						'className'    => 'City',
						'foreignKey' => false,
						'conditions' => 'Agreement.builder_agreement_city_id = AgreementCity.id',

					),	
	'CompanyCity' =>  array(
						'className'    => 'City',
						'foreignKey' => false,
						'conditions' => 'Agreement.builder_agreement_company_city = CompanyCity.id',

					),			
	'ManageBy' =>  array(
						'className'    => 'LookupBuilderAgreementManagedBy',
						'foreignKey' => false,
						'conditions' => 'Agreement.builder_agreement_managed_by_id = ManageBy.id',

					),	
	'PrepareBy' =>  array(
						'className'    => 'LookupBuilderAgreementPreparedBy',
						'foreignKey' => false,
						'conditions' => 'Agreement.builder_agreement_prepared_by_id = PrepareBy.id',

					),	
	'AgreementPrimaryCode' => array(
					'className'    => 'LookupValueLeadsCountry',
					'foreignKey' => false,
					'conditions' => 'Agreement.builder_agreement_contact_primary_mobile_code = AgreementPrimaryCode.id',
					
					),
					
	'AgreementSecondaryCode' => array(
					'className'    => 'LookupValueLeadsCountry',
					'foreignKey' => false,
					'conditions' => 'Agreement.builder_agreement_contact_secondary_mobile_code = AgreementSecondaryCode.id',
					
					),
	'AgreementLanCode' => array(
					'className'    => 'LookupValueLeadsCountry',
					'foreignKey' => false,
					'conditions' => 'Agreement.builder_agreement_lan_country_code = AgreementLanCode.id',
					
					),	
	'BuilderContact' => array(
					'className'    => 'BuilderContact',
					'foreignKey' => false,
					'conditions' => 'Builder.id = BuilderContact.builder_contact_builder_id',
					),	
	'ContactStatus' =>  array(
						'className'    => 'LookupBuilderContactStatus',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_status = ContactStatus.id',

					),	
	'LookupBuilderContactInitiatedBy' =>  array(
						'className'    => 'LookupBuilderContactInitiatedBy',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_intiated_by_id = LookupBuilderContactInitiatedBy.id',

					),	
	'LookupBuilderContactManagedBy' =>  array(
						'className'    => 'LookupBuilderContactManagedBy',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_managed_by_id = LookupBuilderContactManagedBy.id',

					),	
	'BuilderContactCompanyCity' =>  array(
						'className'    => 'city',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_company_city = BuilderContactCompanyCity.id',

					),
	'LookupBuilderContactPreparedBy' =>  array(
						'className'    => 'LookupBuilderContactPreparedBy',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_prepared_by_id = LookupBuilderContactPreparedBy.id',

					),
	'BuilderContactMobileCode' =>  array(
						'className'    => 'LookupValueLeadsCountry',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_mobile_country_code = BuilderContactMobileCode.id',

					),
	'BuilderContactSecondaryMobileCode' =>  array(
						'className'    => 'LookupValueLeadsCountry',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_secondary_mobile_country_code = BuilderContactSecondaryMobileCode.id',

					),	
	'BuilderContactLanCode' =>  array(
						'className'    => 'LookupValueLeadsCountry',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_lan_no_country_code = BuilderContactLanCode.id',

					),																										
	'ActionItemBuilder' =>  array(
						'className'    => 'ActionItem',
						'foreignKey' => false,
						'conditions' => 'Builder.id = ActionItemBuilder.builder_id',

					),	
	'BuilderContactLevel' =>  array(
						'className'    => 'LookupBuilderContactLevel',
						'foreignKey' => false,
						'conditions' => 'BuilderContact.builder_contact_level = BuilderContactLevel.id',

					),																															
/*	'PrimaryCode' => array(
					'className'    => 'LookupValueLeadsCountry',
					'foreignKey'   => 'builder_primary_mobile_code'
					),
					
	'SecondaryCode' => array(
					'className'    => 'LookupValueLeadsCountry',
					'foreignKey'   => 'builder_secondary_mobile_code'
					),*/												
    );
	
	var $hasMany = array(   
        'ProjectAgreement' => array(
                    'className' => 'ProjectAgreement',
                    'foreignKey' => 'project_agreement_builder_id',
		  
                    )
	);	
	
}
?>