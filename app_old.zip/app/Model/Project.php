<?php

App::uses('AppModel', 'Model');

class Project extends AppModel {

    public $name = 'Project';
    public $validate = array(
        'project_name' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'Please provide project name'
            )
        ),
        'city_id' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'Please provide city name'
            )
        ),
        'builder_id' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'Please provide builder name'
            )
        ),
         'proj_brochure_edit' => array(
            'rule' => array('extension',array('pdf', 'docx', 'doc', 'txt','xlsx')),
           // 'required' => 'create',
           // 'allowEmpty' => true,
            'message' => 'Please supply a valid file',
            'on' => 'update',
            'last'=>true
        ),
        'proj_image' => array(
            'rule' => array('extension',array('jpeg','jpg','png','gif')),
            'required' => 'create',
            'allowEmpty' => true,
            'message' => 'Select Valid Image',
            'on' => 'create',
            'last'=>true
        ),
       
        'proj_image_edit' => array(
            'rule' => array('extension',array('jpeg','jpg','png','gif')),
           // 'required' => 'create',
            //'allowEmpty' => true,
            'message' => 'Select Valid Image',
            'on' => 'update',
            'last'=>true
        ),
        'proj_brochure' => array(
            'rule' => array('extension',array('pdf', 'docx', 'doc', 'txt','xlsx')),
            'required' => 'create',
            'allowEmpty' => true,
            'message' => 'Please supply a valid file',
            'on' => 'create',
            'last'=>true
        ),
        
        
    );
    public $belongsTo = array(
        'Suburb' => array(
            'className' => 'Suburb',
            'foreignKey' => 'suburb_id'
        ),
        'Builder' => array(
            'className' => 'Builder',
            'foreignKey' => 'builder_id'
        ),
        'City' => array(
            'className' => 'City',
            'foreignKey' => 'city_id'
        ),
        'Area' => array(
            'className' => 'Area',
            'foreignKey' => 'area_id'
        ),
        'Type' => array(
            'className' => 'Type',
            'foreignKey' => 'type_id'
        ),
        'Phase' => array(
            'className' => 'Phase',
            'foreignKey' => 'phase_id'
        ),
        'Category' => array(
            'className' => 'Category',
            'foreignKey' => 'category_id'
        ),
        'Quality' => array(
            'className' => 'Quality',
            'foreignKey' => 'quality_id'
        ),
        'Marketing' => array(
            'className' => 'Marketing',
            'foreignKey' => 'marketing_id'
        ),
	'LookupValueStatus' => array(
	    'className' => 'LookupValueStatus',
	    'foreignKey' => 'proj_status'
	),
	'Residetal' => array(
	    'className' => 'LookupValueStatus',
	    'foreignKey' => 'proj_residential'
	),
	'Commercial' => array(
	    'className' => 'LookupValueStatus',
	    'foreignKey' => 'proj_commercial'
	),
	
    );

    
    /*
    public $hasMany = array(
			    'Amenity' => array(
				    'className' => 'Amenity',
				    'foreignKey'   => false,
				    'conditions' => 'Project.id = Amenity.project_id',
			    ),
				
			   );
			   */
    /*
    public $hasOne = 'Amenity';
    public $hasMany = array(
        'Amenity' => array(
            'className' => 'Amenity',
            'foreignKey' => 'project_id',
            'dependent' => false
        )
    );
    */    

}

?>