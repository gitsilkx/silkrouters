<?php
echo "<><><><><>";
echo $_REQUEST['simple_editor'];