# Readme

Full documentation on [MyJqueryPlugins](http://www.myjqueryplugins.com/jquery-plugin/jmenu)

Demonstration on [jMenu demonstration page](http://demos.myjqueryplugins.com/jmenu/)