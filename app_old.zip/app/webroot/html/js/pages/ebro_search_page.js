/* [ ---- Ebro Admin - search page ---- ] */

    $(function() {
		//* price slider
		if($('#price_slider').length) {
			$("#price_slider").ionRangeSlider();
		}
	})